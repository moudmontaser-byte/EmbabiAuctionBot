package com.embabi.hiddenplayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.RectF;

public final class Prefs {
    public static final String NAME = "embabi_hidden_player";
    public static final String THRESHOLD = "threshold"; // legacy default
    public static final String CURRENT_ROUND = "current_round";
    private static final String ROUND_THRESHOLD_PREFIX = "round_threshold_";
    public static final String REPEAT_MODE = "repeat_mode";
    public static final String REPEAT_COUNT = "repeat_count";
    public static final String REPEAT_MINUTES = "repeat_minutes";
    public static final String REGION_L = "region_l";
    public static final String REGION_T = "region_t";
    public static final String REGION_R = "region_r";
    public static final String REGION_B = "region_b";
    public static final String REGION_SET = "region_set";

    public static final String BOT_WANTED = "bot_wanted";
    public static final String BOT_PAUSED = "bot_paused";
    public static final String OVERLAY_WANTED = "overlay_wanted";
    public static final String LAST_STATUS = "last_status";
    public static final String LAST_RATING = "last_rating";
    public static final String LAST_DECISION = "last_decision";
    public static final String MATCHES_COMPLETED = "matches_completed";
    public static final String BOT_STARTED_AT = "bot_started_at";
    public static final String ACCESS_HEARTBEAT = "access_heartbeat";

    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static int threshold(Context c) { return get(c).getInt(THRESHOLD, 85); }
    public static int thresholdForRound(Context c, int round) {
        int r=Math.max(1,Math.min(11,round));
        SharedPreferences p=get(c);
        String key=ROUND_THRESHOLD_PREFIX+r;
        return p.contains(key)?p.getInt(key,85):threshold(c);
    }
    public static void setThresholdForRound(Context c,int round,int value){
        int r=Math.max(1,Math.min(11,round));
        int v=Math.max(50,Math.min(99,value));
        get(c).edit().putInt(ROUND_THRESHOLD_PREFIX+r,v).apply();
    }
    public static int currentRound(Context c){ return Math.max(1,Math.min(11,get(c).getInt(CURRENT_ROUND,1))); }
    public static void setCurrentRound(Context c,int round){ get(c).edit().putInt(CURRENT_ROUND,Math.max(1,Math.min(11,round))).apply(); }
    public static String repeatMode(Context c) { return get(c).getString(REPEAT_MODE, "infinite"); }
    public static int repeatCount(Context c) { return Math.max(1, get(c).getInt(REPEAT_COUNT, 10)); }
    public static int repeatMinutes(Context c) { return Math.max(1, get(c).getInt(REPEAT_MINUTES, 60)); }
    public static boolean hasRegion(Context c) { return get(c).getBoolean(REGION_SET, false); }

    public static boolean botWanted(Context c) { return get(c).getBoolean(BOT_WANTED, false); }
    public static boolean botPaused(Context c) { return get(c).getBoolean(BOT_PAUSED, false); }
    public static boolean overlayWanted(Context c) { return get(c).getBoolean(OVERLAY_WANTED, false); }
    public static String lastStatus(Context c) { return get(c).getString(LAST_STATUS, "جاهز — افتح Embabi Games"); }
    public static int lastRating(Context c) { return get(c).getInt(LAST_RATING, -1); }
    public static String lastDecision(Context c) { return get(c).getString(LAST_DECISION, "—"); }
    public static int matchesCompleted(Context c) { return Math.max(0, get(c).getInt(MATCHES_COMPLETED, 0)); }
    public static long botStartedAt(Context c) { return get(c).getLong(BOT_STARTED_AT, 0L); }
    public static long accessHeartbeat(Context c){ return get(c).getLong(ACCESS_HEARTBEAT,0L); }

    public static void setBotWanted(Context c, boolean wanted) {
        get(c).edit().putBoolean(BOT_WANTED, wanted).apply();
    }
    public static void setBotStartedAt(Context c,long when){ get(c).edit().putLong(BOT_STARTED_AT,when).apply(); }
    public static void setAccessHeartbeat(Context c,long when){ get(c).edit().putLong(ACCESS_HEARTBEAT,when).apply(); }
    public static void setBotPaused(Context c, boolean paused) {
        get(c).edit().putBoolean(BOT_PAUSED, paused).apply();
    }
    public static void setOverlayWanted(Context c, boolean wanted) {
        get(c).edit().putBoolean(OVERLAY_WANTED, wanted).apply();
    }
    public static void saveRuntime(Context c, String status, Integer rating, String decision, int matches) {
        SharedPreferences.Editor e=get(c).edit();
        if(status!=null)e.putString(LAST_STATUS,status);
        e.putInt(LAST_RATING,rating==null?-1:rating);
        if(decision!=null)e.putString(LAST_DECISION,decision);
        e.putInt(MATCHES_COMPLETED,Math.max(0,matches));
        e.apply();
    }

    public static RectF region(Context c) {
        SharedPreferences p = get(c);
        return new RectF(
                p.getFloat(REGION_L, .59f),
                p.getFloat(REGION_T, .48f),
                p.getFloat(REGION_R, .77f),
                p.getFloat(REGION_B, .60f));
    }

    public static void saveRegion(Context c, RectF n) {
        get(c).edit()
                .putBoolean(REGION_SET, true)
                .putFloat(REGION_L, n.left)
                .putFloat(REGION_T, n.top)
                .putFloat(REGION_R, n.right)
                .putFloat(REGION_B, n.bottom)
                .apply();
    }
}
