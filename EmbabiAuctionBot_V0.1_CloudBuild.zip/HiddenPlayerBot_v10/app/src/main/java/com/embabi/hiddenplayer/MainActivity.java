package com.embabi.hiddenplayer;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Build;
import android.net.Uri;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.*;

import java.util.List;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(5, 14, 27);
    private final int card = Color.rgb(11, 27, 46);
    private final int card2 = Color.rgb(13, 34, 57);
    private final int white = Color.rgb(244, 247, 255);
    private final int muted = Color.rgb(154, 174, 202);
    private final int purple = Color.rgb(117, 83, 255);
    private final int blue = Color.rgb(31, 149, 255);
    private final int green = Color.rgb(0, 220, 136);
    private final int red = Color.rgb(255, 65, 92);

    private TextView statusText, regionState, serviceState;
    private Button infiniteBtn, countBtn, timeBtn;
    private EditText countInput, minutesInput;
    private BroadcastReceiver statusReceiver;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        statusReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String s = intent.getStringExtra(BotActions.EXTRA_STATUS);
                if (s != null) statusText.setText(s);
            }
        };
        registerReceiver(statusReceiver, new IntentFilter(BotActions.STATUS), RECEIVER_NOT_EXPORTED);
    }

    @Override protected void onResume() {
        super.onResume();
        updateServiceState();
        updateRegionState();
        if(Prefs.overlayWanted(this) && hasOverlayPermission()) startOverlayKeeper();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (statusReceiver != null) unregisterReceiver(statusReceiver);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = text("◈", 34, purple, true);
        TextView title = text("EMBABI GAMES\nHIDDEN PLAYER BOT", 21, white, true);
        title.setGravity(Gravity.RIGHT);
        title.setPadding(dp(12), 0, 0, 0);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        titleRow.addView(logo, new LinearLayout.LayoutParams(dp(52), dp(52)));
        root.addView(titleRow);

        LinearLayout statusCard = cardBox(green, 18);
        LinearLayout dotRow = new LinearLayout(this); dotRow.setGravity(Gravity.CENTER_VERTICAL); dotRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView ready = text("جاهز للتشغيل", 18, green, true);
        serviceState = text("فعّل Accessibility ثم استخدم لوحة التحكم العائمة فوق Embabi Games", 13, muted, false);
        LinearLayout statusTexts = new LinearLayout(this); statusTexts.setOrientation(LinearLayout.VERTICAL); statusTexts.addView(ready); statusTexts.addView(serviceState);
        TextView dot = text("●", 28, green, true);
        dotRow.addView(statusTexts, new LinearLayout.LayoutParams(0, -2, 1)); dotRow.addView(dot);
        statusCard.addView(dotRow);
        root.addView(statusCard, marginTop(16));

        LinearLayout serviceCard = cardBox(blue, 14);
        TextView h = text("صلاحية مراقبة الشاشة", 17, white, true); serviceCard.addView(h);
        TextView d = text("الخدمة تستخدم Accessibility لقراءة حالة الصفحة وأخذ Screenshot للـ OCR.", 13, muted, false); d.setPadding(0, dp(5), 0, dp(12)); serviceCard.addView(d);
        Button accessBtn = button("فتح إعدادات Accessibility", blue, Color.WHITE);
        accessBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        serviceCard.addView(accessBtn);
        Button overlayBtn = button("السماح بالظهور فوق التطبيقات", Color.rgb(31,55,84), Color.WHITE);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(50));op.topMargin=dp(8);
        overlayBtn.setLayoutParams(op);
        overlayBtn.setOnClickListener(v -> requestOverlayPermission());
        serviceCard.addView(overlayBtn);
        Button batteryBtn = button("إعدادات البطارية — اختر Unrestricted", Color.rgb(31,55,84), Color.WHITE);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(50));bp.topMargin=dp(8);batteryBtn.setLayoutParams(bp);
        batteryBtn.setOnClickListener(v -> { try{ startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))); Toast.makeText(this,"ادخل Battery واختر Unrestricted",Toast.LENGTH_LONG).show(); }catch(Exception ignored){} });
        serviceCard.addView(batteryBtn);
        root.addView(serviceCard, marginTop(12));

        LinearLayout repeat = cardBox(purple, 14);
        repeat.addView(text("وضع التكرار", 18, white, true));
        TextView repeatSub = text("حدد متى يتوقف البوت بعد كل مباراة", 13, muted, false); repeatSub.setPadding(0,dp(3),0,dp(10)); repeat.addView(repeatSub);
        LinearLayout tabs = new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); tabs.setWeightSum(3);
        infiniteBtn = segment("∞  لا نهائي"); countBtn = segment("#  عدد مباريات"); timeBtn = segment("◷  وقت محدد");
        tabs.addView(infiniteBtn, new LinearLayout.LayoutParams(0, dp(52), 1)); tabs.addView(countBtn, new LinearLayout.LayoutParams(0, dp(52), 1)); tabs.addView(timeBtn, new LinearLayout.LayoutParams(0, dp(52), 1)); repeat.addView(tabs);
        LinearLayout inputs = new LinearLayout(this); inputs.setOrientation(LinearLayout.HORIZONTAL); inputs.setPadding(0,dp(10),0,0);
        countInput = numberInput("عدد المباريات", Prefs.repeatCount(this));
        minutesInput = numberInput("المدة بالدقائق", Prefs.repeatMinutes(this));
        inputs.addView(countInput, new LinearLayout.LayoutParams(0,dp(50),1));
        Space sp = new Space(this); inputs.addView(sp,new LinearLayout.LayoutParams(dp(8),1));
        inputs.addView(minutesInput, new LinearLayout.LayoutParams(0,dp(50),1)); repeat.addView(inputs);
        infiniteBtn.setOnClickListener(v -> selectRepeat("infinite")); countBtn.setOnClickListener(v -> selectRepeat("count")); timeBtn.setOnClickListener(v -> selectRepeat("time"));
        selectRepeat(Prefs.repeatMode(this)); root.addView(repeat, marginTop(12));

        LinearLayout threshold = cardBox(purple, 14);
        threshold.addView(text("حد التقييم لكل لاعب — 1 إلى 11", 18, white, true));
        TextView thSub = text("كل جولة لها حد مستقل. إذا التقييم يساوي الحد أو أعلى أختار اللاعب الظاهر.", 13, muted, false); thSub.setPadding(0,dp(4),0,dp(10)); threshold.addView(thSub);
        for(int round=1; round<=11; round++){
            final int rr=round;
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(3),0,dp(3));
            TextView label=text(String.valueOf(round),16,white,true); label.setGravity(Gravity.CENTER);
            Button minus=smallButton("−");
            TextView value=text(String.valueOf(Prefs.thresholdForRound(this,round)),20,white,true); value.setGravity(Gravity.CENTER);
            Button plus=smallButton("+");
            minus.setOnClickListener(v->{int nv=Math.max(50,Prefs.thresholdForRound(this,rr)-1);Prefs.setThresholdForRound(this,rr,nv);value.setText(String.valueOf(nv));});
            plus.setOnClickListener(v->{int nv=Math.min(99,Prefs.thresholdForRound(this,rr)+1);Prefs.setThresholdForRound(this,rr,nv);value.setText(String.valueOf(nv));});
            row.addView(label,new LinearLayout.LayoutParams(dp(54),dp(46)));
            row.addView(minus,new LinearLayout.LayoutParams(dp(54),dp(46)));
            row.addView(value,new LinearLayout.LayoutParams(0,dp(46),1));
            row.addView(plus,new LinearLayout.LayoutParams(dp(54),dp(46)));
            threshold.addView(row);
        }
        root.addView(threshold, marginTop(12));

        LinearLayout region = cardBox(blue, 14);
        region.addView(text("منطقة قراءة التقييم — اليمين", 18, white, true));
        regionState = text("لم يتم تحديد المنطقة بعد", 13, muted, false); regionState.setPadding(0,dp(4),0,dp(10)); region.addView(regionState);
        LinearLayout regionBtns = new LinearLayout(this); regionBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button setRegion = button("تحديد المنطقة", blue, Color.WHITE); Button test = button("اختبار OCR", Color.rgb(30,47,72), white);
        setRegion.setOnClickListener(v -> requestRegion()); test.setOnClickListener(v -> requestTest());
        regionBtns.addView(setRegion,new LinearLayout.LayoutParams(0,dp(52),1)); Space rs = new Space(this); regionBtns.addView(rs,new LinearLayout.LayoutParams(dp(8),1)); regionBtns.addView(test,new LinearLayout.LayoutParams(0,dp(52),1)); region.addView(regionBtns);
        root.addView(region, marginTop(12));

        LinearLayout current = cardBox(Color.rgb(0,190,220), 14);
        current.addView(text("الحالة الحالية", 18, white, true));
        statusText = text("في انتظار بدء التشغيل…\n• مراقبة الشاشة\n• تحديد دوري أو دور الخصم\n• قراءة تقييم اليمين\n• اختيار اللاعب المناسب", 14, Color.rgb(185,205,231), false);
        statusText.setLineSpacing(0,1.22f); statusText.setPadding(dp(2),dp(8),dp(2),dp(5)); current.addView(statusText);
        root.addView(current, marginTop(12));

        Button start = button("◈   إظهار لوحة التحكم فوق اللعبة", green, Color.rgb(0,44,31)); start.setTextSize(18); start.setTypeface(null,1); start.setOnClickListener(v -> showOverlayAndLeave()); root.addView(start, marginTop(14,60));
        LinearLayout stopRow = new LinearLayout(this); stopRow.setOrientation(LinearLayout.HORIZONTAL);
        Button stop = button("■  إيقاف", Color.rgb(74,18,31), red); Button pause = button("Ⅱ  إيقاف مؤقت", Color.rgb(21,37,57), white);
        stop.setOnClickListener(v -> send(BotActions.STOP)); pause.setOnClickListener(v -> send(BotActions.PAUSE));
        stopRow.addView(stop,new LinearLayout.LayoutParams(0,dp(54),1)); Space ss=new Space(this); stopRow.addView(ss,new LinearLayout.LayoutParams(dp(8),1)); stopRow.addView(pause,new LinearLayout.LayoutParams(0,dp(54),1)); root.addView(stopRow, marginTop(10));

        TextView foot = text("Floating Control • المراقبة والتحكم بالكامل فوق Embabi Games", 12, Color.rgb(105,127,157), false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(16),0,0); root.addView(foot);
        setContentView(scroll);
    }

    private void requestRegion() {
        if (!hasOverlayPermission()) { requestOverlayPermission(); return; }
        if (!isServiceEnabled()) { Toast.makeText(this,"فعّل Accessibility أولاً",Toast.LENGTH_SHORT).show(); startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
        startOverlayKeeper();
        Toast.makeText(this,"ارجع للعبة: سيظهر تحديد المربع فوق Embabi Games مباشرة",Toast.LENGTH_LONG).show();
        send(BotActions.CAPTURE_REGION); moveTaskToBack(true);
    }

    private void requestTest() {
        if (!Prefs.hasRegion(this)) { Toast.makeText(this,"حدد منطقة التقييم أولاً",Toast.LENGTH_SHORT).show(); return; }
        if (!hasOverlayPermission()) { requestOverlayPermission(); return; }
        if (!isServiceEnabled()) { Toast.makeText(this,"فعّل Accessibility أولاً",Toast.LENGTH_SHORT).show(); return; }
        startOverlayKeeper(); send(BotActions.TEST_OCR); moveTaskToBack(true);
    }

    private void startBot() {
        showOverlayAndLeave();
    }

    private void showOverlayAndLeave() {
        saveSettings();
        Prefs.setOverlayWanted(this,true);
        if (!hasOverlayPermission()) { requestOverlayPermission(); return; }
        startOverlayKeeper();
        send(BotActions.SHOW_OVERLAY);
        Toast.makeText(this,isServiceEnabled()?"لوحة التحكم ثابتة فوق اللعبة — ابدأ منها":"اللوحة ستظهر، لكن Accessibility غير مفعّل",Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    private boolean hasOverlayPermission(){ return Settings.canDrawOverlays(this); }

    private void requestOverlayPermission(){
        Prefs.setOverlayWanted(this,true);
        try{
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivity(i);
            Toast.makeText(this,"فعّل السماح بالظهور فوق التطبيقات ثم ارجع",Toast.LENGTH_LONG).show();
        }catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void startOverlayKeeper(){
        Intent i=new Intent(this,OverlayService.class);
        try{ if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }catch(Exception ignored){}
    }

    private void saveSettings() {
        int c = parse(countInput,10); int m=parse(minutesInput,60);
        Prefs.get(this).edit().putInt(Prefs.REPEAT_COUNT,c).putInt(Prefs.REPEAT_MINUTES,m).apply();
    }

    private int parse(EditText e, int def) { try { return Math.max(1,Integer.parseInt(e.getText().toString().trim())); } catch(Exception x){ return def; } }
    private void send(String action) { sendBroadcast(new Intent(action).setPackage(getPackageName())); }

    private void selectRepeat(String mode) {
        Prefs.get(this).edit().putString(Prefs.REPEAT_MODE, mode).apply();
        styleSegment(infiniteBtn, mode.equals("infinite")); styleSegment(countBtn, mode.equals("count")); styleSegment(timeBtn, mode.equals("time"));
        countInput.setEnabled(mode.equals("count")); minutesInput.setEnabled(mode.equals("time"));
        countInput.setAlpha(mode.equals("count")?1f:.38f); minutesInput.setAlpha(mode.equals("time")?1f:.38f);
    }

    private void styleSegment(Button b, boolean on) { b.setTextColor(on?Color.WHITE:muted); b.setBackground(round(on?Color.rgb(80,55,188):Color.rgb(14,30,50), on?purple:Color.rgb(44,65,90), 12)); }

    private void updateRegionState() {
        if (regionState == null) return;
        if (Prefs.hasRegion(this)) {
            android.graphics.RectF r=Prefs.region(this);
            regionState.setText(String.format(java.util.Locale.US,"محفوظ ✓   X %.0f%%–%.0f%%   Y %.0f%%–%.0f%%",r.left*100,r.right*100,r.top*100,r.bottom*100)); regionState.setTextColor(green);
        } else { regionState.setText("لم يتم تحديد المنطقة بعد"); regionState.setTextColor(muted); }
    }

    private void updateServiceState() {
        boolean on=isServiceEnabled();
        if(serviceState!=null){ serviceState.setText(on?"Accessibility مفعّل ✓ — جاهز لمراقبة Embabi Games":"Accessibility غير مفعّل — اضغط لفتحه من الإعدادات"); serviceState.setTextColor(on?green:muted); }
    }

    private boolean isServiceEnabled() {
        AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> list=am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for(AccessibilityServiceInfo i:list){ if(i.getResolveInfo()!=null && getPackageName().equals(i.getResolveInfo().serviceInfo.packageName)) return true; }
        return false;
    }

    private LinearLayout cardBox(int stroke, int radius) { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(15),dp(16),dp(15)); l.setBackground(round(card,stroke,radius)); return l; }
    private TextView text(String s,float sp,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); if(bold)t.setTypeface(null,1); return t; }
    private Button button(String s,int fill,int color){ Button b=new Button(this); b.setAllCaps(false); b.setText(s); b.setTextColor(color); b.setTextSize(15); b.setGravity(Gravity.CENTER); b.setBackground(round(fill, brighten(fill),14)); b.setPadding(dp(10),0,dp(10),0); return b; }
    private Button segment(String s){ Button b=button(s,Color.rgb(14,30,50),muted); b.setTextSize(13); return b; }
    private Button smallButton(String s){ Button b=button(s,Color.rgb(19,38,61),white); b.setTextSize(25); return b; }
    private EditText numberInput(String hint,int value){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(101,123,152)); e.setTextColor(white); e.setTextSize(14); e.setGravity(Gravity.CENTER); e.setInputType(InputType.TYPE_CLASS_NUMBER); e.setText(String.valueOf(value)); e.setBackground(round(Color.rgb(8,22,38),Color.rgb(45,68,96),10)); return e; }
    private GradientDrawable round(int fill,int stroke,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radius)); g.setStroke(dp(1),stroke); return g; }
    private int brighten(int c){ return Color.rgb(Math.min(255,Color.red(c)+25),Math.min(255,Color.green(c)+25),Math.min(255,Color.blue(c)+25)); }
    private LinearLayout.LayoutParams marginTop(int top){ return marginTop(top,-2); }
    private LinearLayout.LayoutParams marginTop(int top,int h){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h); p.topMargin=dp(top); return p; }
    private int dp(int v){ return Math.round(v*getResources().getDisplayMetrics().density); }
}
