package com.embabi.hiddenplayer;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.view.accessibility.AccessibilityManager;
import android.widget.*;

import java.util.List;

public class OverlayService extends Service {
    private static final String CHANNEL_ID="embabi_hidden_overlay";
    private static final int NOTIFICATION_ID=7331;
    private final Handler h=new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private View floatingView;
    private WindowManager.LayoutParams floatingLp;
    private boolean expanded=true;
    private boolean thresholdsPanel=false;
    private boolean tempHidden=false;
    private BroadcastReceiver receiver;

    private TextView ovStatus,ovRating,ovDecision,ovRoundThreshold,ovRepeat,ovRunState;

    private final Runnable watchdog=new Runnable(){
        @Override public void run(){
            if(!Prefs.overlayWanted(OverlayService.this)){
                stopSelf(); return;
            }
            boolean access=isAccessibilityConnected();
            if(!tempHidden && Settings.canDrawOverlays(OverlayService.this)){
                if(floatingView==null || !floatingView.isAttachedToWindow()) showOverlay(expanded);
            }
            refresh(access);
            updateNotification(access);
            h.postDelayed(this,1200);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        createChannel();
        startForeground(NOTIFICATION_ID,buildNotification(isAccessibilityConnected()));

        receiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c,Intent i){
                String a=i.getAction();
                if(BotActions.STATUS.equals(a) || BotActions.STATE.equals(a)) refresh(isAccessibilityConnected());
                else if(BotActions.TEMP_HIDE_OVERLAY.equals(a)){tempHidden=true;removeOverlay();}
                else if(BotActions.TEMP_SHOW_OVERLAY.equals(a)){tempHidden=false;if(Settings.canDrawOverlays(OverlayService.this))showOverlay(expanded);}
                else if(BotActions.SHOW_OVERLAY.equals(a)){Prefs.setOverlayWanted(OverlayService.this,true);tempHidden=false;if(Settings.canDrawOverlays(OverlayService.this))showOverlay(expanded);}
                else if(BotActions.HIDE_OVERLAY.equals(a)){Prefs.setOverlayWanted(OverlayService.this,false);stopSelf();}
            }
        };
        IntentFilter f=new IntentFilter();
        f.addAction(BotActions.STATUS);f.addAction(BotActions.STATE);f.addAction(BotActions.TEMP_HIDE_OVERLAY);
        f.addAction(BotActions.TEMP_SHOW_OVERLAY);f.addAction(BotActions.SHOW_OVERLAY);f.addAction(BotActions.HIDE_OVERLAY);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);

        expanded=Prefs.get(this).getBoolean("overlay_expanded",true);
        if(Prefs.overlayWanted(this) && Settings.canDrawOverlays(this))showOverlay(expanded);
        h.post(watchdog);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Prefs.setOverlayWanted(this,true);
        if(Settings.canDrawOverlays(this) && !tempHidden && (floatingView==null || !floatingView.isAttachedToWindow()))showOverlay(expanded);
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent){
        if(Prefs.overlayWanted(this)){
            try{
                Intent i=new Intent(getApplicationContext(),OverlayService.class);
                if(Build.VERSION.SDK_INT>=26)getApplicationContext().startForegroundService(i);else getApplicationContext().startService(i);
            }catch(Exception ignored){}
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy(){
        h.removeCallbacksAndMessages(null);
        removeOverlay();
        if(receiver!=null)try{unregisterReceiver(receiver);}catch(Exception ignored){}
        boolean restart=Prefs.overlayWanted(this);
        super.onDestroy();
        if(restart){
            try{
                Intent i=new Intent(getApplicationContext(),OverlayService.class);
                if(Build.VERSION.SDK_INT>=26)getApplicationContext().startForegroundService(i);else getApplicationContext().startService(i);
            }catch(Exception ignored){}
        }
    }

    @Override public IBinder onBind(Intent intent){return null;}

    private void createChannel(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"Embabi Hidden Player",NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Keeps the Hidden Player control overlay active");
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotification(boolean access){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,7,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String state=access?"Overlay active • Accessibility ON":"Overlay active • Accessibility OFF — tap to fix";
        Notification.Builder b=new Notification.Builder(this,CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Embabi Hidden Player")
                .setContentText(state)
                .setContentIntent(pi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true);
        if(Build.VERSION.SDK_INT>=31)b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void updateNotification(boolean access){
        try{((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,buildNotification(access));}catch(Exception ignored){}
    }

    private boolean isAccessibilityEnabled(){
        try{
            AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
            List<AccessibilityServiceInfo> list=am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            for(AccessibilityServiceInfo info:list){
                if(info.getResolveInfo()!=null && getPackageName().equals(info.getResolveInfo().serviceInfo.packageName))return true;
            }
        }catch(Exception ignored){}
        return false;
    }

    private boolean isAccessibilityConnected(){
        if(!isAccessibilityEnabled())return false;
        long hb=Prefs.accessHeartbeat(this);
        return hb>0 && System.currentTimeMillis()-hb<4500L;
    }

    private void openAccessibility(){
        try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}
    }

    private void send(String action){sendBroadcast(new Intent(action).setPackage(getPackageName()));}

    private void showOverlay(boolean wantExpanded){
        if(!Settings.canDrawOverlays(this))return;
        expanded=wantExpanded;
        Prefs.get(this).edit().putBoolean("overlay_expanded",expanded).apply();
        removeOverlay();

        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(8),dp(10),dp(10));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);box.setBackground(round(Color.argb(246,7,18,32),Color.rgb(84,78,220),16));

        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=ovText("◈ HIDDEN PLAYER",14,Color.WHITE,true);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        TextView collapse=ovText(expanded?"—":"☰",20,Color.rgb(160,186,255),true);collapse.setGravity(Gravity.CENTER);collapse.setPadding(dp(8),0,dp(8),0);
        TextView close=ovText("×",22,Color.rgb(255,105,125),true);close.setGravity(Gravity.CENTER);close.setPadding(dp(5),0,dp(5),0);
        head.addView(title,new LinearLayout.LayoutParams(0,dp(38),1));head.addView(collapse,new LinearLayout.LayoutParams(dp(42),dp(38)));head.addView(close,new LinearLayout.LayoutParams(dp(42),dp(38)));box.addView(head);

        if(expanded && thresholdsPanel){
            TextView listTitle=ovText("حدود التقييم لكل جولة",15,Color.WHITE,true); listTitle.setGravity(Gravity.CENTER); listTitle.setPadding(0,dp(4),0,dp(6)); box.addView(listTitle);
            TextView hint=ovText("كل سطر مستقل • إذا Rating ≥ الحد أختار الظاهر",10,Color.rgb(166,185,210),false); hint.setGravity(Gravity.CENTER); box.addView(hint);
            ScrollView sc=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,dp(5),0,dp(5)); sc.addView(list,new ScrollView.LayoutParams(-1,-2));
            int current=Prefs.currentRound(this);
            for(int round=1;round<=11;round++){
                final int rr=round;
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(2),0,dp(2));
                TextView label=ovText(String.valueOf(round),13,round==current?Color.rgb(0,230,150):Color.WHITE,true); label.setGravity(Gravity.CENTER);
                Button minus=ovButton("−",Color.rgb(24,45,68));
                TextView value=ovText(String.valueOf(Prefs.thresholdForRound(this,round)),17,Color.WHITE,true); value.setGravity(Gravity.CENTER);
                Button plus=ovButton("+",Color.rgb(24,45,68));
                minus.setOnClickListener(v->{adjustRoundThreshold(rr,-1); showOverlay(true);});
                plus.setOnClickListener(v->{adjustRoundThreshold(rr,1); showOverlay(true);});
                row.addView(label,new LinearLayout.LayoutParams(dp(44),dp(38))); row.addView(minus,new LinearLayout.LayoutParams(dp(48),dp(38))); row.addView(value,new LinearLayout.LayoutParams(0,dp(38),1)); row.addView(plus,new LinearLayout.LayoutParams(dp(48),dp(38)));
                list.addView(row);
            }
            box.addView(sc,new LinearLayout.LayoutParams(-1,dp(330)));
            Button back=ovButton("رجوع للتحكم",Color.rgb(31,91,150)); back.setOnClickListener(v->{thresholdsPanel=false;showOverlay(true);}); box.addView(back,new LinearLayout.LayoutParams(-1,dp(42)));
        } else if(expanded){
            ovRunState=ovText("",12,Color.rgb(0,230,150),true);box.addView(ovRunState);
            ovStatus=ovText(Prefs.lastStatus(this),12,Color.rgb(207,219,239),false);ovStatus.setMaxLines(3);ovStatus.setPadding(0,dp(4),0,dp(7));box.addView(ovStatus);

            LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.HORIZONTAL);
            ovRating=chip("Rating: —",Color.rgb(15,45,67));ovDecision=chip("قرار: —",Color.rgb(15,45,67));
            stats.addView(ovRating,new LinearLayout.LayoutParams(0,dp(38),1));addGap(stats,6);stats.addView(ovDecision,new LinearLayout.LayoutParams(0,dp(38),1));box.addView(stats);

            LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);controls.setPadding(0,dp(7),0,0);
            Button start=ovButton("▶ START",Color.rgb(0,191,120));Button pause=ovButton("Ⅱ PAUSE",Color.rgb(26,55,82));Button stop=ovButton("■ STOP",Color.rgb(105,24,42));
            start.setOnClickListener(v->{Prefs.setBotWanted(this,true);Prefs.setBotPaused(this,false);if(isAccessibilityConnected())send(BotActions.START);else{Prefs.saveRuntime(this,"⚠ Accessibility OFF — اضغط السطر الأخضر لفتحه",null,Prefs.lastDecision(this),Prefs.matchesCompleted(this));openAccessibility();}refresh(isAccessibilityConnected());});
            pause.setOnClickListener(v->{if(isAccessibilityConnected())send(BotActions.PAUSE);else openAccessibility();});
            stop.setOnClickListener(v->{Prefs.setBotWanted(this,false);Prefs.setBotPaused(this,false);send(BotActions.STOP);refresh(isAccessibilityConnected());});
            controls.addView(start,new LinearLayout.LayoutParams(0,dp(43),1));addGap(controls,5);controls.addView(pause,new LinearLayout.LayoutParams(0,dp(43),1));addGap(controls,5);controls.addView(stop,new LinearLayout.LayoutParams(0,dp(43),1));box.addView(controls);

            LinearLayout th=new LinearLayout(this);th.setOrientation(LinearLayout.HORIZONTAL);th.setGravity(Gravity.CENTER_VERTICAL);th.setPadding(0,dp(7),0,0);
            Button thresholds=ovButton("☷ حدود 1–11",Color.rgb(63,45,151));
            ovRoundThreshold=ovText("",12,Color.rgb(210,224,244),true);ovRoundThreshold.setGravity(Gravity.CENTER);
            thresholds.setOnClickListener(v->{thresholdsPanel=true;showOverlay(true);});
            th.addView(ovRoundThreshold,new LinearLayout.LayoutParams(0,dp(42),1)); addGap(th,5); th.addView(thresholds,new LinearLayout.LayoutParams(dp(115),dp(42))); box.addView(th);

            LinearLayout rep=new LinearLayout(this);rep.setOrientation(LinearLayout.HORIZONTAL);rep.setPadding(0,dp(6),0,0);
            Button inf=ovButton("∞",Color.rgb(63,45,151));Button cnt=ovButton("#",Color.rgb(26,55,82));Button tim=ovButton("◷",Color.rgb(26,55,82));
            ovRepeat=ovText(repeatLabel(),12,Color.rgb(186,202,225),true);ovRepeat.setGravity(Gravity.CENTER_VERTICAL);
            inf.setOnClickListener(v->setRepeatMode("infinite"));cnt.setOnClickListener(v->setRepeatMode("count"));tim.setOnClickListener(v->setRepeatMode("time"));
            rep.addView(ovRepeat,new LinearLayout.LayoutParams(0,dp(42),1));rep.addView(inf,new LinearLayout.LayoutParams(dp(44),dp(42)));addGap(rep,4);rep.addView(cnt,new LinearLayout.LayoutParams(dp(44),dp(42)));addGap(rep,4);rep.addView(tim,new LinearLayout.LayoutParams(dp(44),dp(42)));box.addView(rep);

            LinearLayout adjust=new LinearLayout(this);adjust.setOrientation(LinearLayout.HORIZONTAL);adjust.setPadding(0,dp(5),0,0);
            Button dec=ovButton("− قيمة",Color.rgb(24,45,68));Button inc=ovButton("+ قيمة",Color.rgb(24,45,68));dec.setOnClickListener(v->adjustRepeat(-1));inc.setOnClickListener(v->adjustRepeat(1));
            adjust.addView(dec,new LinearLayout.LayoutParams(0,dp(40),1));addGap(adjust,5);adjust.addView(inc,new LinearLayout.LayoutParams(0,dp(40),1));box.addView(adjust);

            LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);tools.setPadding(0,dp(7),0,0);
            Button region=ovButton("▣ حدد المربع",Color.rgb(25,133,220));Button test=ovButton("◎ TEST OCR",Color.rgb(34,58,86));
            region.setOnClickListener(v->{if(isAccessibilityConnected())send(BotActions.CAPTURE_REGION);else openAccessibility();});
            test.setOnClickListener(v->{if(isAccessibilityConnected())send(BotActions.TEST_OCR);else openAccessibility();});
            tools.addView(region,new LinearLayout.LayoutParams(0,dp(44),1));addGap(tools,5);tools.addView(test,new LinearLayout.LayoutParams(0,dp(44),1));box.addView(tools);
        }else{
            ovStatus=ovText(shortStatus(isAccessibilityConnected()),11,Color.rgb(205,219,241),true);ovStatus.setGravity(Gravity.CENTER);box.addView(ovStatus,new LinearLayout.LayoutParams(-1,dp(34)));
        }

        collapse.setOnClickListener(v->showOverlay(!expanded));
        close.setOnClickListener(v->{
            Prefs.setBotWanted(this,false);Prefs.setBotPaused(this,false);Prefs.setOverlayWanted(this,false);send(BotActions.STOP);removeOverlay();stopSelf();
        });

        ovRunState=ovRunState;
        if(ovRunState!=null)ovRunState.setOnClickListener(v->{if(!isAccessibilityConnected())openAccessibility();});
        if(ovStatus!=null)ovStatus.setOnClickListener(v->{if(!isAccessibilityConnected())openAccessibility();});

        floatingLp=new WindowManager.LayoutParams(expanded?dp(310):dp(170),WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        floatingLp.gravity=Gravity.TOP|Gravity.START;
        floatingLp.x=Prefs.get(this).getInt("overlay_x",dp(8));floatingLp.y=Prefs.get(this).getInt("overlay_y",dp(80));
        floatingView=box;makeDraggable(head);
        try{wm.addView(floatingView,floatingLp);}catch(Exception e){floatingView=null;}
        refresh(isAccessibilityConnected());
    }

    private String shortStatus(boolean access){
        if(!access)return "⚠ Accessibility OFF";
        if(!Prefs.botWanted(this))return "جاهز • اضغط START";
        if(Prefs.botPaused(this))return "PAUSED";
        int r=Prefs.lastRating(this);if(r>=0)return "R "+r+" • "+Prefs.lastDecision(this);
        return "مراقبة الشاشة…";
    }

    private void refresh(boolean access){
        if(floatingView==null)return;
        String status=Prefs.lastStatus(this);
        int rating=Prefs.lastRating(this);
        String decision=Prefs.lastDecision(this);
        if(!access && Prefs.botWanted(this))status="⚠ Accessibility OFF — اضغط هنا لإعادة التفعيل";
        if(ovStatus!=null)ovStatus.setText(expanded?status:shortStatus(access));
        if(ovRating!=null)ovRating.setText("Rating: "+(rating<0?"—":rating));
        if(ovDecision!=null)ovDecision.setText("قرار: "+decision);
        if(ovRoundThreshold!=null){int rr=Prefs.currentRound(this);ovRoundThreshold.setText("الجولة "+rr+"/11 • الحد "+Prefs.thresholdForRound(this,rr));}
        if(ovRepeat!=null)ovRepeat.setText(repeatLabel());
        if(ovRunState!=null){
            String t;if(!access)t="● ACCESSIBILITY OFF — اضغط هنا";else if(!Prefs.botWanted(this))t="● جاهز";else if(Prefs.botPaused(this))t="● متوقف مؤقتًا";else t="● يعمل • Match "+(Prefs.matchesCompleted(this)+1);
            ovRunState.setText(t);ovRunState.setTextColor(!access?Color.rgb(255,85,105):!Prefs.botWanted(this)?Color.rgb(120,160,190):Prefs.botPaused(this)?Color.rgb(255,195,75):Color.rgb(0,230,150));
        }
    }

    private void makeDraggable(View handle){
        handle.setOnTouchListener(new View.OnTouchListener(){
            int sx,sy;float dx,dy;boolean moved;
            @Override public boolean onTouch(View v,MotionEvent e){
                if(floatingLp==null||floatingView==null)return false;
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=floatingLp.x;sy=floatingLp.y;dx=e.getRawX();dy=e.getRawY();moved=false;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){int nx=sx+(int)(e.getRawX()-dx),ny=sy+(int)(e.getRawY()-dy);if(Math.abs(nx-sx)>4||Math.abs(ny-sy)>4)moved=true;floatingLp.x=Math.max(0,nx);floatingLp.y=Math.max(0,ny);try{wm.updateViewLayout(floatingView,floatingLp);}catch(Exception ignored){}return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){Prefs.get(OverlayService.this).edit().putInt("overlay_x",floatingLp.x).putInt("overlay_y",floatingLp.y).apply();if(!moved)showOverlay(!expanded);return true;}
                return false;
            }
        });
    }

    private void removeOverlay(){if(floatingView!=null&&wm!=null)try{wm.removeView(floatingView);}catch(Exception ignored){}floatingView=null;ovStatus=null;ovRating=null;ovDecision=null;ovRoundThreshold=null;ovRepeat=null;ovRunState=null;}

    private void adjustRoundThreshold(int round,int delta){int v=Math.max(50,Math.min(99,Prefs.thresholdForRound(this,round)+delta));Prefs.setThresholdForRound(this,round,v);refresh(isAccessibilityConnected());}
    private void setRepeatMode(String mode){Prefs.get(this).edit().putString(Prefs.REPEAT_MODE,mode).apply();refresh(isAccessibilityConnected());}
    private void adjustRepeat(int dir){String m=Prefs.repeatMode(this);if("infinite".equals(m))return;if("count".equals(m)){int v=Math.max(1,Prefs.repeatCount(this)+dir);Prefs.get(this).edit().putInt(Prefs.REPEAT_COUNT,v).apply();}else{int v=Math.max(5,Prefs.repeatMinutes(this)+dir*5);Prefs.get(this).edit().putInt(Prefs.REPEAT_MINUTES,v).apply();}refresh(isAccessibilityConnected());}
    private String repeatLabel(){String m=Prefs.repeatMode(this);if("count".equals(m))return "التكرار: "+Prefs.repeatCount(this)+" مباراة";if("time".equals(m))return "التكرار: "+Prefs.repeatMinutes(this)+" دقيقة";return "التكرار: لا نهائي ∞";}

    private TextView ovText(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);return t;}
    private TextView chip(String s,int fill){TextView t=ovText(s,11,Color.rgb(218,229,245),true);t.setGravity(Gravity.CENTER);t.setBackground(round(fill,Color.rgb(45,73,103),10));return t;}
    private Button ovButton(String s,int fill){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextSize(11);b.setTextColor(Color.WHITE);b.setPadding(dp(4),0,dp(4),0);b.setBackground(round(fill,Color.rgb(Math.min(255,Color.red(fill)+25),Math.min(255,Color.green(fill)+25),Math.min(255,Color.blue(fill)+25)),10));return b;}
    private void addGap(LinearLayout l,int d){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(dp(d),1));}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
