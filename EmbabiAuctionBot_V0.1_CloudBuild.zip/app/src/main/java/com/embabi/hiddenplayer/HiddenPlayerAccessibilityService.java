package com.embabi.hiddenplayer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.*;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HiddenPlayerAccessibilityService extends AccessibilityService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private BroadcastReceiver receiver;
    private boolean running=false, paused=false, scanQueued=false, screenshotBusy=false, readingRating=false;
    private boolean actedThisTurn=false, pendingConfirm=false, leftMyTurnAfterAction=false;
    private boolean lineupsClicked=false, awaitingGamesArrow=false, awaitingMain=false, stopAfterReturn=false;
    private long startedAt=0;
    private int matchesCompleted=0;
    private String lastStatus="";
    private long lastActionAt=0;

    private final Runnable monitor = new Runnable() {
        @Override public void run() {
            if (running && !paused) analyzeCurrentScreen();
            if (running) h.postDelayed(this, 550);
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                String a=i.getAction();
                if(BotActions.START.equals(a)) startBot();
                else if(BotActions.STOP.equals(a)) stopBot("تم إيقاف البوت يدويًا");
                else if(BotActions.PAUSE.equals(a)) { paused=!paused; status(paused?"إيقاف مؤقت — المراقبة متوقفة":"استئناف المراقبة…"); if(!paused) analyzeCurrentScreen(); }
                else if(BotActions.CAPTURE_REGION.equals(a)) h.postDelayed(HiddenPlayerAccessibilityService.this::captureForRegion, 850);
                else if(BotActions.TEST_OCR.equals(a)) h.postDelayed(HiddenPlayerAccessibilityService.this::testOcr, 850);
            }
        };
        IntentFilter f=new IntentFilter(); f.addAction(BotActions.START); f.addAction(BotActions.STOP); f.addAction(BotActions.PAUSE); f.addAction(BotActions.CAPTURE_REGION); f.addAction(BotActions.TEST_OCR);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        status("Accessibility جاهز ✓");
    }

    @Override public void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if(receiver!=null) try{unregisterReceiver(receiver);}catch(Exception ignored){}
        recognizer.close();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(running && !paused) queueScan(90);
    }
    @Override public void onInterrupt() { }

    private void startBot(){
        running=true; paused=false; actedThisTurn=false; pendingConfirm=false; leftMyTurnAfterAction=false; lineupsClicked=false; awaitingGamesArrow=false; awaitingMain=false; stopAfterReturn=false; matchesCompleted=0; startedAt=System.currentTimeMillis();
        h.removeCallbacks(monitor); h.post(monitor); status("بدأ التشغيل ✓ — أراقب الشاشة الآن"); analyzeCurrentScreen();
    }
    private void stopBot(String s){ running=false;paused=false;h.removeCallbacks(monitor);status(s); }
    private void queueScan(long delay){ if(scanQueued)return; scanQueued=true; h.postDelayed(()->{scanQueued=false; if(running&&!paused) analyzeCurrentScreen();},delay); }

    private void analyzeCurrentScreen(){
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null){ status("أراقب الشاشة… لم أجد عناصر قابلة للقراءة بعد"); return; }
        String all=normalize(collectText(root));

        // 1) Finish the post-match flow exactly as in the new interface.
        if(awaitingGamesArrow){
            if(contains(all,"الالعاب")){
                status("صفحة الألعاب ظهرت — أضغط السهم الرمادي");
                clickTopRightArrow(root);
                awaitingGamesArrow=false; awaitingMain=true; return;
            }
        }
        if(awaitingMain){
            if(contains(all,"العب الان")){
                if(stopAfterReturn){ stopBot("اكتملت دورة التكرار ✓ — عدنا للرئيسية"); return; }
                awaitingMain=false; lineupsClicked=false;
                status("الرئيسية جاهزة — أبدأ مباراة جديدة");
                clickText(root,"العب الان"); return;
            }
        }

        boolean resultScreen = containsAny(all,"ملخص المباراه","رجل المباراه","الاهداف والكروت","خذ المكافاه");
        if(resultScreen || lineupsClicked){
            pendingConfirm=false; actedThisTurn=false;
            if(!lineupsClicked){
                AccessibilityNodeInfo n=findText(root,"عرض التشكيلات");
                if(n!=null){ status("نهاية المباراة — أضغط عرض التشكيلات"); if(clickNode(n)){lineupsClicked=true; queueScan(250);} return; }
                status("نهاية المباراة — أنزل حتى عرض التشكيلات"); scrollForward(root); return;
            } else {
                AccessibilityNodeInfo n=findText(root,"العوده للرئيسيه");
                if(n!=null){ status("التشكيلات ظهرت — أضغط العودة للرئيسية"); if(clickNode(n)){ onMatchCompleted(); awaitingGamesArrow=true; queueScan(300);} return; }
                status("بعد عرض التشكيلات — أنزل حتى العودة للرئيسية"); scrollForward(root); return;
            }
        }

        // 2) Navigation to a new Hidden Player match (new interface only).
        if(contains(all,"هاتلي منافس")){
            status("جاهز للبحث — أضغط هاتلي منافس!"); clickText(root,"هاتلي منافس"); return;
        }
        if(contains(all,"اختر الكارت") && contains(all,"تحدي")){
            status("مود اللاعب الخفي جاهز — أضغط العب"); clickBestPlayButton(root); return;
        }
        if(contains(all,"الالعاب") && contains(all,"اللاعب الخفي") && !contains(all,"اختر الكارت")){
            if(awaitingGamesArrow) return;
            status("صفحة الألعاب — أفتح اللاعب الخفي"); clickText(root,"اللاعب الخفي"); return;
        }
        if(contains(all,"العب الان") && !contains(all,"اختر الكارت")){
            status("الصفحة الرئيسية — أضغط العب الآن"); clickText(root,"العب الان"); return;
        }

        // 3) Match state: opponent vs my turn.
        boolean opponentTurn = containsAny(all,"خصمك يختار","خصمك يقرر","خصمك يختار اللاعب","خصمك اختار");
        boolean myTurn = containsAny(all,"اختر اللاعب","اختار اللاعب");

        if(opponentTurn){
            if(actedThisTurn && !pendingConfirm) leftMyTurnAfterAction=true;
            if(leftMyTurnAfterAction){actedThisTurn=false;leftMyTurnAfterAction=false;}
            status("دور الخصم — لا ألمس أي شيء، أراقب التغيير"); return;
        }

        if(pendingConfirm){
            AccessibilityNodeInfo c=findText(root,"تاكيد الاختيار");
            if(c!=null && isEnabledClickable(c)){
                status("الاختيار تم — أضغط تأكيد الاختيار"); clickNode(c); pendingConfirm=false; queueScan(220); return;
            }
            status("اللاعب اتحدد — أراقب زر تأكيد الاختيار");
            captureBitmap(this::confirmIfYellow);
            return;
        }

        if(myTurn){
            if(!actedThisTurn && !readingRating){
                status("دوري ✓ — أقرأ تقييم اللاعب اليمين من المربع المحدد");
                readRatingAndChoose();
            } else status("دوري — تم اتخاذ القرار لهذه الجولة، أراقب انتقال الشاشة");
            return;
        }

        if(actedThisTurn){ leftMyTurnAfterAction=true; }
        status("أراقب الشاشة… في انتظار دوري أو تغيّر الحالة");
    }

    private void readRatingAndChoose(){
        if(!Prefs.hasRegion(this)){ choosePlayer(null); return; }
        readingRating=true;
        captureBitmap(bmp->{
            if(bmp==null){readingRating=false;choosePlayer(null);return;}
            RectF n=Prefs.region(this);
            int l=Math.max(0,Math.min(bmp.getWidth()-1,Math.round(n.left*bmp.getWidth())));
            int t=Math.max(0,Math.min(bmp.getHeight()-1,Math.round(n.top*bmp.getHeight())));
            int r=Math.max(l+1,Math.min(bmp.getWidth(),Math.round(n.right*bmp.getWidth())));
            int b=Math.max(t+1,Math.min(bmp.getHeight(),Math.round(n.bottom*bmp.getHeight())));
            Bitmap crop=Bitmap.createBitmap(bmp,l,t,r-l,b-t);
            recognizer.process(InputImage.fromBitmap(crop,0)).addOnSuccessListener(text->{ Integer rating=extractRating(text.getText()); readingRating=false; choosePlayer(rating); crop.recycle(); }).addOnFailureListener(e->{readingRating=false;choosePlayer(null);crop.recycle();});
        });
    }

    private Integer extractRating(String raw){
        if(raw==null)return null;
        String s=raw.toUpperCase(Locale.US).replace('O','0').replace('S','5').replace('B','8').replace('I','1').replace('L','1');
        Matcher m=Pattern.compile("(?<!\\d)([5-9]\\d)(?!\\d)").matcher(s);
        Integer best=null; while(m.find()){try{int v=Integer.parseInt(m.group(1)); if(v>=50&&v<=99){best=v;break;}}catch(Exception ignored){}}
        return best;
    }

    private void choosePlayer(Integer rating){
        int threshold=Prefs.threshold(this); boolean visible=rating!=null && rating>=threshold;
        String read=rating==null?"غير مقروء":String.valueOf(rating);
        status("التقييم: "+read+" — "+(visible?"أختار اللاعب الظاهر يمين":"أختار اللاعب الخفي شمال"));
        RectF reg=Prefs.region(this); float x=visible?(reg.centerX()):(1f-reg.centerX()); float y=reg.centerY();
        tapNormalized(x,y);
        actedThisTurn=true; pendingConfirm=true; lastActionAt=System.currentTimeMillis(); queueScan(180);
    }

    private void confirmIfYellow(Bitmap bmp){
        if(bmp==null||!pendingConfirm)return;
        int w=bmp.getWidth(),hgt=bmp.getHeight(); int l=(int)(.08*w),r=(int)(.92*w),t=(int)(.82*hgt),b=(int)(.94*hgt); int yellow=0,total=0;
        int sx=Math.max(2,(r-l)/90), sy=Math.max(2,(b-t)/30);
        for(int y=t;y<b;y+=sy)for(int x=l;x<r;x+=sx){int c=bmp.getPixel(x,y);int rr=Color.red(c),gg=Color.green(c),bb=Color.blue(c);if(rr>175&&gg>135&&bb<110&&rr>bb*1.5)yellow++;total++;}
        if(total>0 && yellow/(float)total>.055f){ status("زر التأكيد أصبح فعالًا — أؤكد الاختيار"); tapNormalized(.5f,.885f); pendingConfirm=false; queueScan(250); }
    }

    private void onMatchCompleted(){
        matchesCompleted++;
        String mode=Prefs.repeatMode(this);
        if("count".equals(mode) && matchesCompleted>=Prefs.repeatCount(this)) stopAfterReturn=true;
        if("time".equals(mode) && System.currentTimeMillis()-startedAt>=Prefs.repeatMinutes(this)*60_000L) stopAfterReturn=true;
        status("انتهت المباراة #"+matchesCompleted+(stopAfterReturn?" — سأعود للرئيسية ثم أتوقف":" — سأبدأ مباراة جديدة"));
    }

    private void captureForRegion(){
        captureBitmap(bmp->{
            if(bmp==null){Toast.makeText(this,"تعذر أخذ Screenshot",Toast.LENGTH_SHORT).show();return;}
            try{
                File f=new File(getCacheDir(),"rating_region_source.png"); FileOutputStream out=new FileOutputStream(f); bmp.compress(Bitmap.CompressFormat.PNG,100,out); out.close();
                Intent i=new Intent(this,RegionPickerActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);i.putExtra("screenshot",f.getAbsolutePath());startActivity(i);
            }catch(Exception e){Toast.makeText(this,"تعذر حفظ لقطة الشاشة",Toast.LENGTH_SHORT).show();}
        });
    }

    private void testOcr(){
        if(!Prefs.hasRegion(this)){Toast.makeText(this,"حدد المنطقة أولاً",Toast.LENGTH_SHORT).show();return;}
        captureBitmap(bmp->{
            if(bmp==null)return; RectF n=Prefs.region(this); int l=Math.max(0,(int)(n.left*bmp.getWidth())),t=Math.max(0,(int)(n.top*bmp.getHeight())),r=Math.min(bmp.getWidth(),Math.max(l+1,(int)(n.right*bmp.getWidth()))),b=Math.min(bmp.getHeight(),Math.max(t+1,(int)(n.bottom*bmp.getHeight()))); Bitmap crop=Bitmap.createBitmap(bmp,l,t,r-l,b-t);
            recognizer.process(InputImage.fromBitmap(crop,0)).addOnSuccessListener(tx->{Integer v=extractRating(tx.getText());String s=v==null?"OCR: لم أقرأ تقييمًا — أثناء اللعب سيختار الخفي":"OCR قرأ التقييم: "+v;Toast.makeText(this,s,Toast.LENGTH_LONG).show();status(s);crop.recycle();}).addOnFailureListener(e->Toast.makeText(this,"فشل اختبار OCR",Toast.LENGTH_SHORT).show());
        });
    }

    private interface BitmapConsumer{void accept(Bitmap b);}
    private void captureBitmap(BitmapConsumer cb){
        if(screenshotBusy){cb.accept(null);return;} screenshotBusy=true;
        try{
            takeScreenshot(0,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    HardwareBuffer hb=result.getHardwareBuffer(); Bitmap hw=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace()); Bitmap copy=hw==null?null:hw.copy(Bitmap.Config.ARGB_8888,false); hb.close(); screenshotBusy=false; cb.accept(copy); }
                @Override public void onFailure(int errorCode){screenshotBusy=false;cb.accept(null);}
            });
        }catch(Exception e){screenshotBusy=false;cb.accept(null);}
    }

    private String collectText(AccessibilityNodeInfo root){ StringBuilder sb=new StringBuilder(); collect(root,sb,0); return sb.toString(); }
    private void collect(AccessibilityNodeInfo n,StringBuilder sb,int depth){ if(n==null||depth>40)return; CharSequence t=n.getText(),d=n.getContentDescription(); if(t!=null)sb.append(' ').append(t); if(d!=null)sb.append(' ').append(d); for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),sb,depth+1); }
    private String normalize(String s){ if(s==null)return""; s=Normalizer.normalize(s,Normalizer.Form.NFKD).replaceAll("[\\u064B-\\u065F\\u0670]",""); return s.replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ة','ه').replace('ى','ي').replace('ؤ','و').replace('ئ','ي').replaceAll("\\s+"," ").trim().toLowerCase(Locale.ROOT); }
    private boolean contains(String all,String q){return all.contains(normalize(q));}
    private boolean containsAny(String all,String...qs){for(String q:qs)if(contains(all,q))return true;return false;}

    private AccessibilityNodeInfo findText(AccessibilityNodeInfo root,String q){ String nq=normalize(q); return findTextRec(root,nq,0); }
    private AccessibilityNodeInfo findTextRec(AccessibilityNodeInfo n,String q,int depth){ if(n==null||depth>40)return null; String s=normalize(((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString()))); if(s.contains(q))return n; for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findTextRec(n.getChild(i),q,depth+1);if(r!=null)return r;} return null; }
    private boolean clickText(AccessibilityNodeInfo root,String q){AccessibilityNodeInfo n=findText(root,q);return n!=null&&clickNode(n);}
    private boolean clickNode(AccessibilityNodeInfo n){ AccessibilityNodeInfo cur=n; for(int i=0;i<7&&cur!=null;i++,cur=cur.getParent()){if(cur.isClickable()&&cur.isEnabled()){cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);lastActionAt=System.currentTimeMillis();return true;}} Rect r=new Rect();n.getBoundsInScreen(r);if(!r.isEmpty()){tapPx(r.centerX(),r.centerY());return true;}return false; }
    private boolean isEnabledClickable(AccessibilityNodeInfo n){AccessibilityNodeInfo c=n;for(int i=0;i<6&&c!=null;i++,c=c.getParent())if(c.isClickable()&&c.isEnabled())return true;return false;}
    private void clickBestPlayButton(AccessibilityNodeInfo root){ AccessibilityNodeInfo n=findText(root,"العب"); if(n!=null){Rect r=new Rect();n.getBoundsInScreen(r); if(r.centerY()>getResources().getDisplayMetrics().heightPixels*.55f){clickNode(n);return;}} tapNormalized(.5f,.79f); }

    private void clickTopRightArrow(AccessibilityNodeInfo root){
        AccessibilityNodeInfo best=findTopRightClickable(root,null,0); if(best!=null){clickNode(best);return;} tapNormalized(.91f,.075f);
    }
    private AccessibilityNodeInfo findTopRightClickable(AccessibilityNodeInfo n,AccessibilityNodeInfo best,int depth){ if(n==null||depth>35)return best; if(n.isClickable()&&n.isEnabled()){Rect r=new Rect();n.getBoundsInScreen(r);int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;if(r.centerX()>.72*w&&r.centerY()<.18*hgt&&r.width()>25&&r.height()>25)best=n;} for(int i=0;i<n.getChildCount();i++)best=findTopRightClickable(n.getChild(i),best,depth+1); return best; }

    private boolean scrollForward(AccessibilityNodeInfo root){ AccessibilityNodeInfo s=findScrollable(root,0); if(s!=null){s.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);queueScan(250);return true;} performGlobalAction(GLOBAL_ACTION_BACK); return false; }
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n,int depth){if(n==null||depth>35)return null;if(n.isScrollable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findScrollable(n.getChild(i),depth+1);if(r!=null)return r;}return null;}

    private void tapNormalized(float nx,float ny){int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;tapPx(Math.round(nx*w),Math.round(ny*hgt));}
    private void tapPx(float x,float y){Path p=new Path();p.moveTo(x,y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,70);GestureDescription g=new GestureDescription.Builder().addStroke(s).build();dispatchGesture(g,null,null);lastActionAt=System.currentTimeMillis();}

    private void status(String s){ if(s.equals(lastStatus))return; lastStatus=s; Intent i=new Intent(BotActions.STATUS).setPackage(getPackageName());i.putExtra(BotActions.EXTRA_STATUS,s);sendBroadcast(i); }
}
