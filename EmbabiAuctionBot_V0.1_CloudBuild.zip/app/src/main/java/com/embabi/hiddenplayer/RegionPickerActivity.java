package com.embabi.hiddenplayer;

import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import java.io.File;

public class RegionPickerActivity extends Activity {
    private CropView cropView;
    private Bitmap bitmap;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,14,27));
        getWindow().setNavigationBarColor(Color.rgb(5,14,27));
        String path=getIntent().getStringExtra("screenshot");
        bitmap=path==null?null:BitmapFactory.decodeFile(path);
        if(bitmap==null){ Toast.makeText(this,"تعذر فتح لقطة الشاشة",Toast.LENGTH_SHORT).show(); finish(); return; }

        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12),dp(10),dp(12),dp(12)); root.setBackgroundColor(Color.rgb(5,14,27)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView title=new TextView(this); title.setText("تحديد منطقة قراءة التقييم"); title.setTextSize(21); title.setTextColor(Color.WHITE); title.setTypeface(null,1); title.setGravity(Gravity.RIGHT); root.addView(title);
        TextView sub=new TextView(this); sub.setText("اسحب المستطيل فوق تقييم اللاعب الموجود على اليمين فقط"); sub.setTextSize(13); sub.setTextColor(Color.rgb(160,180,207)); sub.setPadding(0,dp(3),0,dp(8)); root.addView(sub);

        cropView=new CropView(); root.addView(cropView,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(10),0,0);
        Button cancel=btn("إلغاء",Color.rgb(31,44,61),Color.WHITE); Button save=btn("حفظ المنطقة ✓",Color.rgb(31,149,255),Color.WHITE);
        cancel.setOnClickListener(v->finish()); save.setOnClickListener(v->{ RectF n=cropView.normalizedSelection(); if(n.width()<.03f||n.height()<.02f){Toast.makeText(this,"كبر المنطقة قليلاً",Toast.LENGTH_SHORT).show();return;} Prefs.saveRegion(this,n); Toast.makeText(this,"تم حفظ منطقة التقييم",Toast.LENGTH_SHORT).show(); finish(); });
        row.addView(cancel,new LinearLayout.LayoutParams(0,dp(54),1)); Space s=new Space(this); row.addView(s,new LinearLayout.LayoutParams(dp(8),1)); row.addView(save,new LinearLayout.LayoutParams(0,dp(54),2)); root.addView(row);
        setContentView(root);
    }

    private Button btn(String t,int c,int tc){ Button b=new Button(this); b.setAllCaps(false); b.setText(t); b.setTextColor(tc); b.setTextSize(15); GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(13)); g.setStroke(dp(1),Color.rgb(75,100,130)); b.setBackground(g); return b; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private class CropView extends View {
        Paint p=new Paint(3), shade=new Paint(3), label=new Paint(3); RectF imageRect=new RectF(), sel=new RectF(); float downX,downY; int mode=0; float handle=dp(28); // 0 move/create, 1 TL,2 TR,3 BL,4 BR
        CropView(){ super(RegionPickerActivity.this); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(Color.rgb(35,193,255)); shade.setColor(Color.argb(130,0,0,0)); label.setColor(Color.WHITE); label.setTextSize(dp(14)); setBackgroundColor(Color.BLACK); }
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float scale=Math.min(getWidth()/(float)bitmap.getWidth(),getHeight()/(float)bitmap.getHeight()); float w=bitmap.getWidth()*scale,h=bitmap.getHeight()*scale; imageRect.set((getWidth()-w)/2f,(getHeight()-h)/2f,(getWidth()+w)/2f,(getHeight()+h)/2f); c.drawBitmap(bitmap,null,imageRect,null);
            if(sel.isEmpty()){ RectF saved=Prefs.region(RegionPickerActivity.this); sel.set(imageRect.left+saved.left*imageRect.width(),imageRect.top+saved.top*imageRect.height(),imageRect.left+saved.right*imageRect.width(),imageRect.top+saved.bottom*imageRect.height()); }
            c.drawRect(imageRect.left,imageRect.top,imageRect.right,sel.top,shade); c.drawRect(imageRect.left,sel.bottom,imageRect.right,imageRect.bottom,shade); c.drawRect(imageRect.left,sel.top,sel.left,sel.bottom,shade); c.drawRect(sel.right,sel.top,imageRect.right,sel.bottom,shade); c.drawRoundRect(sel,dp(8),dp(8),p);
            drawHandle(c,sel.left,sel.top); drawHandle(c,sel.right,sel.top); drawHandle(c,sel.left,sel.bottom); drawHandle(c,sel.right,sel.bottom); c.drawText("RATING OCR",sel.left+dp(8),Math.max(imageRect.top+dp(18),sel.top-dp(8)),label); }
        void drawHandle(Canvas c,float x,float y){ Paint h=new Paint(3);h.setColor(Color.rgb(35,193,255));c.drawCircle(x,y,dp(6),h); }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ float x=clamp(e.getX(),imageRect.left,imageRect.right),y=clamp(e.getY(),imageRect.top,imageRect.bottom); if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;mode=cornerMode(x,y); if(mode==0 && !sel.contains(x,y)){sel.set(x,y,x+1,y+1);mode=5;} invalidate();return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=x-downX,dy=y-downY; if(mode==1){sel.left=x;sel.top=y;} else if(mode==2){sel.right=x;sel.top=y;} else if(mode==3){sel.left=x;sel.bottom=y;} else if(mode==4){sel.right=x;sel.bottom=y;} else if(mode==5){sel.right=x;sel.bottom=y;} else {sel.offset(dx,dy); if(sel.left<imageRect.left)sel.offset(imageRect.left-sel.left,0); if(sel.right>imageRect.right)sel.offset(imageRect.right-sel.right,0); if(sel.top<imageRect.top)sel.offset(0,imageRect.top-sel.top); if(sel.bottom>imageRect.bottom)sel.offset(0,imageRect.bottom-sel.bottom);} normalize(); downX=x;downY=y;invalidate();return true;} return true; }
        int cornerMode(float x,float y){ if(dist(x,y,sel.left,sel.top)<handle)return 1;if(dist(x,y,sel.right,sel.top)<handle)return 2;if(dist(x,y,sel.left,sel.bottom)<handle)return 3;if(dist(x,y,sel.right,sel.bottom)<handle)return 4;return 0; }
        float dist(float x,float y,float a,float b){return (float)Math.hypot(x-a,y-b);} float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
        void normalize(){ if(sel.left>sel.right){float t=sel.left;sel.left=sel.right;sel.right=t;} if(sel.top>sel.bottom){float t=sel.top;sel.top=sel.bottom;sel.bottom=t;} sel.left=clamp(sel.left,imageRect.left,imageRect.right);sel.right=clamp(sel.right,imageRect.left,imageRect.right);sel.top=clamp(sel.top,imageRect.top,imageRect.bottom);sel.bottom=clamp(sel.bottom,imageRect.top,imageRect.bottom); }
        RectF normalizedSelection(){ normalize(); return new RectF((sel.left-imageRect.left)/imageRect.width(),(sel.top-imageRect.top)/imageRect.height(),(sel.right-imageRect.left)/imageRect.width(),(sel.bottom-imageRect.top)/imageRect.height()); }
    }
}
