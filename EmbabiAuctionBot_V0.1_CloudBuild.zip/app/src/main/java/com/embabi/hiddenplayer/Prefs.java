package com.embabi.hiddenplayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.RectF;

public final class Prefs {
    private static final String NAME = "hidden_player_prefs";
    public static final String THRESHOLD = "threshold";
    public static final String REPEAT_MODE = "repeat_mode"; // infinite, count, time
    public static final String REPEAT_COUNT = "repeat_count";
    public static final String REPEAT_MINUTES = "repeat_minutes";
    public static final String REGION_L = "region_l";
    public static final String REGION_T = "region_t";
    public static final String REGION_R = "region_r";
    public static final String REGION_B = "region_b";
    public static final String REGION_SET = "region_set";

    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static int threshold(Context c) { return get(c).getInt(THRESHOLD, 85); }
    public static String repeatMode(Context c) { return get(c).getString(REPEAT_MODE, "infinite"); }
    public static int repeatCount(Context c) { return Math.max(1, get(c).getInt(REPEAT_COUNT, 10)); }
    public static int repeatMinutes(Context c) { return Math.max(1, get(c).getInt(REPEAT_MINUTES, 60)); }
    public static boolean hasRegion(Context c) { return get(c).getBoolean(REGION_SET, false); }

    public static RectF region(Context c) {
        SharedPreferences p = get(c);
        return new RectF(
                p.getFloat(REGION_L, .59f),
                p.getFloat(REGION_T, .48f),
                p.getFloat(REGION_R, .77f),
                p.getFloat(REGION_B, .60f));
    }

    public static void saveRegion(Context c, RectF n) {
        get(c).edit()
                .putBoolean(REGION_SET, true)
                .putFloat(REGION_L, n.left)
                .putFloat(REGION_T, n.top)
                .putFloat(REGION_R, n.right)
                .putFloat(REGION_B, n.bottom)
                .apply();
    }
}
