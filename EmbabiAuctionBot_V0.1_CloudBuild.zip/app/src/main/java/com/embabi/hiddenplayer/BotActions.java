package com.embabi.hiddenplayer;

public final class BotActions {
    private BotActions() {}
    public static final String START = "com.embabi.hiddenplayer.START";
    public static final String STOP = "com.embabi.hiddenplayer.STOP";
    public static final String PAUSE = "com.embabi.hiddenplayer.PAUSE";
    public static final String CAPTURE_REGION = "com.embabi.hiddenplayer.CAPTURE_REGION";
    public static final String TEST_OCR = "com.embabi.hiddenplayer.TEST_OCR";
    public static final String STATUS = "com.embabi.hiddenplayer.STATUS";
    public static final String EXTRA_STATUS = "status";
}
