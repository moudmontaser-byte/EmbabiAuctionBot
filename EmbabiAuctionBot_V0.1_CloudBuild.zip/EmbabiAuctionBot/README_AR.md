# Embabi Hidden Player — v8 Persistent Overlay

## الجديد في v8
- الـOverlay أصبح خدمة مستقلة Foreground Service بدل الاعتماد على عمر Accessibility Service.
- إشعار دائم منخفض الأهمية يبقي لوحة التحكم حية أثناء اللعب.
- START_STICKY + مراقبة كل 1.2 ثانية: لو Android حذف الـOverlay من الشاشة، الخدمة تعيد إنشاؤه تلقائيًا.
- لو Accessibility Service انفصلت لحظيًا ثم رجعت، البوت يستأنف تلقائيًا إذا كان START ما زال مطلوبًا.
- لو Accessibility تم تعطيلها فعليًا، لا يمكن للتطبيق تشغيلها بنفسه لأسباب أمان Android. الـOverlay يظل ظاهرًا ويعرض ACCESSIBILITY OFF ويمكن الضغط على السطر لفتح إعدادات Accessibility.
- زر × ما زال هو الإغلاق الحقيقي: يوقف البوت ويغلق الـOverlay ولا يعيده.
- إضافة صلاحية Display over other apps لأن الـOverlay لم يعد تابعًا لخدمة Accessibility.
- زر داخل التطبيق لفتح إعدادات البطارية؛ على Samsung يُفضّل Battery > Unrestricted.
- منطق اللعب v7 محفوظ كما هو: ثانية بين الخطوات، اختيار وسط صورة اللاعب، Post-match state machine، Scroll، عرض التشكيلات/النتائج، العودة للرئيسية، ثم السهم الرمادي فقط.

## أول تشغيل بعد تثبيت v8
1. افتح Embabi Hidden Player.
2. اضغط "السماح بالظهور فوق التطبيقات" وفعّل السماح للتطبيق.
3. تأكد أن Accessibility لـ Embabi Hidden Player مفعلة.
4. يفضّل من معلومات التطبيق > Battery اختيار Unrestricted.
5. اضغط "إظهار لوحة التحكم فوق اللعبة".
6. ابدأ من START في الـOverlay.

## إذا Accessibility أغلقت
الـOverlay سيبقى ظاهرًا باللون الأحمر ويعرض ACCESSIBILITY OFF. اضغط على رسالة الحالة لفتح إعدادات Accessibility، فعّل الخدمة، ثم ارجع للعبة. إذا كان البوت كان يعمل قبل الانقطاع فسيستأنف تلقائيًا.
