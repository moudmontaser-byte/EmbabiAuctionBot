## Overlay v4 — Center Tap
- اللاعب الظاهر: Gesture click مباشر في منتصف صورة اللاعب اليمين.
- اللاعب الخفي: Gesture click مباشر في منتصف صورة اللاعب الخفي الشمال.
- بعد الكليك ينتظر تفعيل زر تأكيد الاختيار ثم يضغطه.

## Overlay v3
- يضغط صورة/كارت اللاعب بعد القرار ثم يؤكد الاختيار بعد تفعيل الزر.
- يعيد ضغطة الكارت تلقائياً حتى 3 مرات إذا ظل زر التأكيد غير فعال.
- زر × يغلق اللوحة بالكامل ويوقف البوت لاستخدام الهاتف بشكل طبيعي.

# Embabi Hidden Player Bot — Floating Overlay v2

نسخة جديدة مبنية للواجهة الجديدة في Embabi Games.

## أهم تغيير
التحكم كله من Overlay عائم فوق اللعبة. لا يتم فتح شاشة منفصلة عند تحديد منطقة التقييم، ولا يتم الخروج من اللعبة.

## من اللوحة العائمة يمكنك
- Start / Pause / Stop.
- مشاهدة الحالة الحية: دور الخصم، دوري، Rating، القرار، التأكيد، نهاية المباراة.
- تغيير حد التقييم (الافتراضي 85).
- اختيار التكرار: لا نهائي / عدد مباريات / وقت محدد.
- تعديل عدد المباريات أو الدقائق.
- تحديد مربع قراءة Rating بالسحب مباشرة فوق شاشة Embabi Games.
- Test OCR من نفس اللوحة.
- تصغير اللوحة وتحريكها لأي مكان على الشاشة.

## منطق الاختيار
- Rating >= threshold: اختيار اللاعب الظاهر على اليمين.
- Rating أقل من threshold: اختيار اللاعب الخفي على اليسار.
- إذا لم تتم قراءة Rating: اختيار اللاعب الخفي.
- القرار Screen-driven، وليس مبنيًا على Timer ثابت.

## الملاحظة التقنية
الـ Overlay هو لوحة التحكم فقط. قراءة الشاشة نفسها تتم بواسطة Accessibility screenshot + ML Kit OCR، لذلك لا يلزم MediaProjection popup كل مرة.


## v5 fixes
- Player selection taps calibrated to the exact visual center of the hidden/visible player cards.
- Post-match flow is a strict state machine: View lineups/results -> Return to main -> verify Games hub -> gray arrow -> home.
- Gray arrow is ignored everywhere except the verified Games hub.
- Real swipe gestures are used for post-match scrolling (WebView-safe).
- Buttons must be visibly on-screen before being clicked.
