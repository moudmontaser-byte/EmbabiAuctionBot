package com.mahmod.embabiauctionbot;

public class AuctionSnapshot {
    public boolean auctionScreen;
    public int round = -1;
    public int ownBalance = -1;
    public int oppBalance = -1;
    public int rating = -1;
    public int bid = -1;
    public boolean confirmActive;
    public Leader leader = Leader.UNKNOWN;
    public float confidence;

    public enum Leader { US, OPPONENT, NONE, UNKNOWN }

    @Override public String toString() {
        return "R"+round+" rating="+rating+" bid="+bid+" own="+ownBalance+" opp="+oppBalance+" leader="+leader+" conf="+String.format("%.2f",confidence);
    }
}
