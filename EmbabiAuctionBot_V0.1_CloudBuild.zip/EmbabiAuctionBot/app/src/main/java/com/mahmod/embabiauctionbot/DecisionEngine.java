package com.mahmod.embabiauctionbot;

public class DecisionEngine {
    private final LearningStore learning;
    public DecisionEngine(LearningStore l){learning=l;}

    public Decision decide(AuctionSnapshot s, GameSession game){
        Decision d = new Decision();
        if(!s.auctionScreen || s.confidence < 0.60f){
            d.action=Decision.Action.WAIT; d.reason="قراءة غير مؤكدة"; return d;
        }
        if(s.leader== AuctionSnapshot.Leader.US){
            d.action=Decision.Action.WAIT; d.reason="إحنا في الصدارة"; return d;
        }
        if(!s.confirmActive){
            d.action=Decision.Action.WAIT; d.reason="مش دورنا"; return d;
        }

        int cap = baseCap(s.rating);
        if(s.round==1) cap-=2;
        if(s.round==4) cap+=3;
        if(s.round==5) cap+=7;

        double pUpgrade = learning.upgradeProbability(s.round,s.rating);
        if(!game.freeUpgradeSeen && pUpgrade>=0.30) cap-=4;
        if(game.freeUpgradeSeen) cap+=2;

        // Keep only a small reserve for future player auctions; coach money is intentionally ignored.
        int remaining=Math.max(0,5-s.round);
        int reserve=remaining*5;
        if(s.ownBalance>=0) cap=Math.min(cap, Math.max(1,s.ownBalance-reserve));

        // The opponent can never force us to pay more than their remaining balance + 1.
        if(s.oppBalance>=0) cap=Math.min(cap, s.oppBalance+1);
        cap=Math.max(1,Math.min(95,cap));
        d.maxBid=cap;

        int current=Math.max(0,s.bid);
        if(current>=cap){
            d.action=Decision.Action.SKIP;
            d.reason="السعر وصل السقف " + cap + "M";
            return d;
        }

        // Normal strategy: outbid by the minimum possible amount, never jump blindly.
        d.action=Decision.Action.BID;
        d.deltaMillions=1;
        d.reason="Rating "+s.rating+" | Max "+cap+"M | التالي أقل زيادة";
        return d;
    }

    private int baseCap(int r){
        if(r<=79)return 2;
        if(r<=81)return 5;
        if(r==82)return 8;
        if(r==83)return 11;
        if(r==84)return 15;
        if(r==85)return 20;
        if(r==86)return 25;
        if(r==87)return 31;
        if(r==88)return 38;
        if(r==89)return 45;
        if(r==90)return 54;
        if(r==91)return 60;
        if(r==92)return 66;
        if(r==93)return 71;
        return 76;
    }

    public static class Decision {
        enum Action { WAIT, BID, SKIP }
        Action action=Action.WAIT;
        int maxBid;
        int deltaMillions;
        String reason="";
    }
}
