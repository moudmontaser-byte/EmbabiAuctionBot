package com.mahmod.embabiauctionbot;

import android.graphics.Rect;

public final class ScreenGeometry {
    private ScreenGeometry() {}

    public static Rect rect(int w, int h, double l, double t, double r, double b) {
        return new Rect((int)(w*l), (int)(h*t), (int)(w*r), (int)(h*b));
    }

    // Coordinates estimated from the user's 709x1536 Samsung screenshots.
    public static final double PLUS_X = 0.879, PLUS_Y = 0.805;
    public static final double CONFIRM_X = 0.285, CONFIRM_Y = 0.897;
    public static final double SKIP_X = 0.748, SKIP_Y = 0.897;

    public static final double PLAY_NOW_X = 0.50, PLAY_NOW_Y = 0.625;
    public static final double AUCTION_GAME_X = 0.76, AUCTION_GAME_Y = 0.285;
    public static final double CLASSIC_X = 0.76, CLASSIC_Y = 0.285;
    public static final double NORMAL_CARD_X = 0.78, NORMAL_CARD_Y = 0.630;
    public static final double PLAY_X = 0.50, PLAY_Y = 0.790;
    public static final double FIND_OPPONENT_X = 0.50, FIND_OPPONENT_Y = 0.405;

    public static final double LINEUPS_BUTTON_X = 0.50, LINEUPS_BUTTON_Y = 0.865;
    public static final double BOTTOM_ACTION_X = 0.50, BOTTOM_ACTION_Y = 0.875;

    public static Rect roundRoi(int w,int h){return rect(w,h,.39,.135,.61,.205);}    
    public static Rect ownBalanceRoi(int w,int h){return rect(w,h,.08,.135,.43,.225);}    
    public static Rect oppBalanceRoi(int w,int h){return rect(w,h,.57,.135,.94,.225);}    
    public static Rect timerRoi(int w,int h){return rect(w,h,.32,.205,.68,.285);}    
    public static Rect ratingRoi(int w,int h){return rect(w,h,.14,.34,.45,.56);}    
    public static Rect bidRoi(int w,int h){return rect(w,h,.30,.67,.68,.80);}    
    public static Rect confirmRoi(int w,int h){return rect(w,h,.05,.82,.51,.94);}    
    public static Rect skipRoi(int w,int h){return rect(w,h,.52,.82,.96,.94);}    
    public static Rect leaderRoi(int w,int h){return rect(w,h,.18,.91,.84,.965);}    
    public static Rect revealRatingRoi(int w,int h){return rect(w,h,.12,.22,.46,.58);}    
    public static Rect bottomButtonRoi(int w,int h){return rect(w,h,.05,.77,.96,.93);}    
}
