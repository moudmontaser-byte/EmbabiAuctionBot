package com.mahmod.embabiauctionbot;

import java.util.ArrayList;
import java.util.List;

public class GameSession {
    public long startedAt=System.currentTimeMillis();
    public boolean freeUpgradeSeen=false;
    public int currentRound=0;
    public final List<RoundRecord> rounds=new ArrayList<>();

    public RoundRecord getOrCreate(int round){
        for(RoundRecord r:rounds) if(r.round==round) return r;
        RoundRecord r=new RoundRecord();r.round=round;rounds.add(r);return r;
    }

    public static class RoundRecord {
        public int round;
        public String position="";
        public int auctionRating=-1;
        public int freeRating=-1;
        public int price=-1;
        public boolean wonByUs;
        public int ownBalanceBefore=-1;
        public int oppBalanceBefore=-1;
        public long ts=System.currentTimeMillis();
    }

    public static String positionForRound(int r){
        switch(r){case 1:return "GK";case 2:return "DEF";case 3:return "CM1";case 4:return "CM2";case 5:return "ST";default:return "?";}
    }
}
