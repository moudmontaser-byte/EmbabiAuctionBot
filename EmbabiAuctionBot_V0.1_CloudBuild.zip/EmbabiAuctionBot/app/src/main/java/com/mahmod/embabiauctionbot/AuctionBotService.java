package com.mahmod.embabiauctionbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

public class AuctionBotService extends AccessibilityService {
    private static AuctionBotService instance;
    public static AuctionBotService getInstance(){return instance;}

    private final Handler h=new Handler(Looper.getMainLooper());
    private ScreenAnalyzer analyzer;
    private LearningStore learning;
    private LogStore logs;
    private DecisionEngine engine;
    private GameSession game;

    private boolean running=false, autoActions=false, screenshotBusy=false;
    private long lastAction=0;
    private int lastRound=-1;
    private AuctionSnapshot lastSnapshot;
    private boolean waitingForReveal=false;
    private final Set<Integer> revealRatings=new HashSet<>();
    private TextView overlayStatus;
    private View overlay;

    private final Runnable loop=new Runnable(){@Override public void run(){
        if(running) capture();
        h.postDelayed(this,850);
    }};

    @Override public void onServiceConnected(){
        super.onServiceConnected();
        instance=this;
        analyzer=new ScreenAnalyzer();
        learning=new LearningStore(this);
        logs=new LogStore(this);
        engine=new DecisionEngine(learning);
        showOverlay();
        h.post(loop);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){}

    @Override public void onDestroy(){
        instance=null;
        h.removeCallbacksAndMessages(null);
        if(overlay!=null)((WindowManager)getSystemService(WINDOW_SERVICE)).removeView(overlay);
        super.onDestroy();
    }

    public void startBot(boolean auto, boolean fromHome){
        this.autoActions=auto;
        this.running=true;
        this.game=new GameSession();
        this.lastRound=-1;
        this.waitingForReveal=false;
        this.revealRatings.clear();
        setStatus((auto?"AUTO":"DRY")+" | بدء...");
        // Give the user a few seconds to switch from this app back to Embabi.
        // If START is pressed from the floating overlay while already inside the game,
        // this delay is harmless and avoids accidental taps on our own activity.
        if(auto && fromHome) h.postDelayed(this::navigateFromHome, 3500);
    }

    public void stopBot(){running=false;setStatus("متوقف");}

    private void navigateFromHome(){
        // Timings intentionally conservative; auction detection takes over afterwards.
        tapN(ScreenGeometry.PLAY_NOW_X,ScreenGeometry.PLAY_NOW_Y,0);
        tapN(ScreenGeometry.AUCTION_GAME_X,ScreenGeometry.AUCTION_GAME_Y,1300);
        tapN(ScreenGeometry.CLASSIC_X,ScreenGeometry.CLASSIC_Y,2700);
        tapN(ScreenGeometry.NORMAL_CARD_X,ScreenGeometry.NORMAL_CARD_Y,3100);
        tapN(ScreenGeometry.PLAY_X,ScreenGeometry.PLAY_Y,3900);
        tapN(ScreenGeometry.FIND_OPPONENT_X,ScreenGeometry.FIND_OPPONENT_Y,4700);
    }

    private void capture(){
        if(screenshotBusy)return;
        screenshotBusy=true;
        Executor ex=getMainExecutor();
        takeScreenshot(Display.DEFAULT_DISPLAY,ex,new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){
                HardwareBuffer hb=result.getHardwareBuffer();
                Bitmap hw=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                Bitmap b=hw==null?null:hw.copy(Bitmap.Config.ARGB_8888,false);
                hb.close();
                if(b==null){screenshotBusy=false;return;}
                analyzer.analyze(b,(s,tokens)->{
                    try{processFrame(b,s,tokens);}finally{b.recycle();screenshotBusy=false;}
                });
            }
            @Override public void onFailure(int errorCode){screenshotBusy=false;setStatus("Screenshot error "+errorCode);}
        });
    }

    private void processFrame(Bitmap b, AuctionSnapshot s, List<ScreenAnalyzer.Token> tokens){
        lastSnapshot=s;
        if(s.auctionScreen){
            if(waitingForReveal){waitingForReveal=false;revealRatings.clear();}
            onAuction(s);
            return;
        }

        if(lastRound>=1 && lastRound<=5){
            int rr=analyzer.readRevealRating(b,tokens);
            if(rr>=60 && rr<=99){
                revealRatings.add(rr);
                setStatus((autoActions?"AUTO":"DRY")+" | Reveal: "+revealRatings);
                if(revealRatings.size()>=2 || (revealRatings.size()==1 && System.currentTimeMillis()-lastAction>5200)){
                    finalizeReveal(rr);
                }
                return;
            }
        }

        // After the fifth auction, use color/button flow for the post-auction pages.
        if(game!=null && game.rounds.size()>=5 && System.currentTimeMillis()-lastAction>8000){
            postAuctionFlow(b);
        }
    }

    private void onAuction(AuctionSnapshot s){
        if(game==null)game=new GameSession();
        if(s.round!=lastRound){
            lastRound=s.round;
            game.currentRound=s.round;
            revealRatings.clear();
            GameSession.RoundRecord r=game.getOrCreate(s.round);
            r.position=GameSession.positionForRound(s.round);
            r.auctionRating=s.rating;
            r.ownBalanceBefore=s.ownBalance;
            r.oppBalanceBefore=s.oppBalance;
        }
        GameSession.RoundRecord r=game.getOrCreate(s.round);
        if(r.auctionRating<0)r.auctionRating=s.rating;
        if(r.ownBalanceBefore<0)r.ownBalanceBefore=s.ownBalance;
        if(r.oppBalanceBefore<0)r.oppBalanceBefore=s.oppBalance;

        DecisionEngine.Decision d=engine.decide(s,game);
        setStatus((autoActions?"AUTO":"DRY")+" | "+s.toString()+"\n"+d.reason);
        if(!autoActions)return;
        if(System.currentTimeMillis()-lastAction<1100)return;

        if(d.action== DecisionEngine.Decision.Action.BID){
            // For +1, confirmation alone is the minimum raise in this game's UI.
            // If later the engine requests a larger jump, use PLUS repeatedly then confirm.
            int plusClicks=Math.max(0,d.deltaMillions-1);
            performBid(plusClicks);
            r.wonByUs=true; r.price=Math.max(1,s.bid+1);
        } else if(d.action== DecisionEngine.Decision.Action.SKIP){
            tap(ScreenGeometry.SKIP_X,ScreenGeometry.SKIP_Y);
            r.wonByUs=false; r.price=s.bid;
            waitingForReveal=true;
        }
    }

    private void performBid(int plusClicks){
        long delay=0;
        for(int i=0;i<plusClicks;i++){
            tapN(ScreenGeometry.PLUS_X,ScreenGeometry.PLUS_Y,delay);
            delay+=120;
        }
        tapN(ScreenGeometry.CONFIRM_X,ScreenGeometry.CONFIRM_Y,delay+80);
        lastAction=System.currentTimeMillis();
    }

    private void finalizeReveal(int latest){
        if(game==null||lastRound<1)return;
        GameSession.RoundRecord r=game.getOrCreate(lastRound);
        int free=-1;
        for(int v:revealRatings) if(v!=r.auctionRating){free=v;break;}
        if(free<0 && latest!=r.auctionRating)free=latest;
        if(free<0)return;
        if(r.freeRating<0){
            r.freeRating=free;
            if(free>r.auctionRating)game.freeUpgradeSeen=true;
            learning.observe(r.round,r.auctionRating,free);
            logs.append(game,r);
            setStatus("تعلم: R"+r.round+" "+r.auctionRating+" → free "+free+(free>r.auctionRating?" UPGRADE":""));
        }
        waitingForReveal=false;
        revealRatings.clear();
        lastAction=System.currentTimeMillis();
    }

    private void postAuctionFlow(Bitmap b){
        if(!autoActions)return;
        long now=System.currentTimeMillis();
        if(now-lastAction<1800)return;
        int w=b.getWidth(),hgt=b.getHeight();
        float green=ImageUtil.greenRatio(b,ScreenGeometry.bottomButtonRoi(w,hgt));
        float blue=ImageUtil.blueRatio(b,ScreenGeometry.bottomButtonRoi(w,hgt));
        if(green>0.12f){
            tap(ScreenGeometry.BOTTOM_ACTION_X,ScreenGeometry.BOTTOM_ACTION_Y);
            lastAction=now;
            h.postDelayed(()->swipeUp(),1400);
        } else if(blue>0.10f){
            tap(ScreenGeometry.BOTTOM_ACTION_X,ScreenGeometry.BOTTOM_ACTION_Y);
            lastAction=now;
            h.postDelayed(()->{
                if(running){game=new GameSession();lastRound=-1;revealRatings.clear();navigateFromHome();}
            },2200);
        } else {
            swipeUp();
            lastAction=now;
        }
    }

    private void showOverlay(){
        WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4),dp(3),dp(4),dp(3));box.setBackgroundColor(Color.argb(210,10,31,58));
        overlayStatus=new TextView(this);overlayStatus.setTextColor(Color.WHITE);overlayStatus.setTextSize(9);overlayStatus.setText("Ready");
        box.addView(overlayStatus,new LinearLayout.LayoutParams(dp(188),dp(45)));
        LinearLayout row=new LinearLayout(this);
        Button startBtn=new Button(this);startBtn.setText("START");startBtn.setTextSize(8);
        startBtn.setOnClickListener(v->startBot(autoActions,true));
        Button mode=new Button(this);mode.setText("DRY");mode.setTextSize(8);
        mode.setOnClickListener(v->{autoActions=!autoActions;mode.setText(autoActions?"AUTO":"DRY");setStatus(autoActions?"AUTO جاهز":"DRY جاهز");});
        Button pause=new Button(this);pause.setText("STOP");pause.setTextSize(8);pause.setOnClickListener(v->stopBot());
        row.addView(startBtn,new LinearLayout.LayoutParams(dp(62),dp(40)));
        row.addView(mode,new LinearLayout.LayoutParams(dp(62),dp(40)));
        row.addView(pause,new LinearLayout.LayoutParams(dp(62),dp(40)));
        box.addView(row);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(192),dp(92),WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=dp(4);lp.y=dp(45);
        wm.addView(box,lp);overlay=box;
    }

    private void setStatus(String s){if(overlayStatus!=null)overlayStatus.setText(s);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void tapN(double nx,double ny,long delay){h.postDelayed(()->tap(nx,ny),delay);}
    private void tap(double nx,double ny){
        int w=getResources().getDisplayMetrics().widthPixels, ht=getResources().getDisplayMetrics().heightPixels;
        Path p=new Path();p.moveTo((float)(w*nx),(float)(ht*ny));
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,70);
        GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(stroke);
        dispatchGesture(b.build(),null,null);lastAction=System.currentTimeMillis();
    }

    private void swipeUp(){
        int w=getResources().getDisplayMetrics().widthPixels, ht=getResources().getDisplayMetrics().heightPixels;
        Path p=new Path();p.moveTo(w*.50f,ht*.78f);p.lineTo(w*.50f,ht*.35f);
        GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(new GestureDescription.StrokeDescription(p,0,500));
        dispatchGesture(b.build(),null,null);
    }
}
