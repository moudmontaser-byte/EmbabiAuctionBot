package com.mahmod.embabiauctionbot;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;

public final class ImageUtil {
    private ImageUtil() {}

    public static float greenRatio(Bitmap b, Rect r) {
        int stepX = Math.max(1, r.width()/35);
        int stepY = Math.max(1, r.height()/18);
        int total=0, good=0;
        for(int y=r.top; y<r.bottom; y+=stepY){
            for(int x=r.left; x<r.right; x+=stepX){
                int c=b.getPixel(x,y);
                int rr=Color.red(c), g=Color.green(c), bb=Color.blue(c);
                total++;
                if(g > rr*1.20 && g > bb*1.10 && g>90) good++;
            }
        }
        return total==0?0:(float)good/total;
    }

    public static float redRatio(Bitmap b, Rect r) {
        int stepX = Math.max(1, r.width()/35);
        int stepY = Math.max(1, r.height()/18);
        int total=0, good=0;
        for(int y=r.top; y<r.bottom; y+=stepY){
            for(int x=r.left; x<r.right; x+=stepX){
                int c=b.getPixel(x,y);
                int rr=Color.red(c), g=Color.green(c), bb=Color.blue(c);
                total++;
                if(rr > g*1.22 && rr > bb*1.05 && rr>100) good++;
            }
        }
        return total==0?0:(float)good/total;
    }

    public static float blueRatio(Bitmap b, Rect r) {
        int stepX = Math.max(1, r.width()/35);
        int stepY = Math.max(1, r.height()/18);
        int total=0, good=0;
        for(int y=r.top; y<r.bottom; y+=stepY){
            for(int x=r.left; x<r.right; x+=stepX){
                int c=b.getPixel(x,y);
                int rr=Color.red(c), g=Color.green(c), bb=Color.blue(c);
                total++;
                if(bb > rr*1.25 && bb > g*1.03 && bb>90) good++;
            }
        }
        return total==0?0:(float)good/total;
    }
}
