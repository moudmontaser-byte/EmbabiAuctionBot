package com.mahmod.embabiauctionbot;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogStore {
    private final Context c;
    private final File file;
    public LogStore(Context c){this.c=c.getApplicationContext(); file=new File(c.getFilesDir(),"auction_log.csv"); ensureHeader();}

    private void ensureHeader(){
        if(file.exists()&&file.length()>0)return;
        appendRaw("time,game_start,round,position,auction_rating,free_rating,upgrade,won_by_us,price,own_before,opp_before\\n");
    }

    public synchronized void append(GameSession g, GameSession.RoundRecord r){
        String line=System.currentTimeMillis()+","+g.startedAt+","+r.round+","+r.position+","+r.auctionRating+","+r.freeRating+","+
                (r.freeRating>r.auctionRating?1:0)+","+(r.wonByUs?1:0)+","+r.price+","+r.ownBalanceBefore+","+r.oppBalanceBefore+"\\n";
        appendRaw(line);
    }

    private void appendRaw(String s){
        try(FileOutputStream os=new FileOutputStream(file,true)){os.write(s.getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}
    }

    public void reset(){ if(file.exists())file.delete(); ensureHeader(); }

    public static String exportCsvToDownloads(Context c) throws Exception {
        LogStore store=new LogStore(c);
        String name="embabi_auction_log_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".csv";
        ContentValues v=new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME,name);
        v.put(MediaStore.Downloads.MIME_TYPE,"text/csv");
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri uri=c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(uri==null)throw new Exception("MediaStore insert failed");
        try(FileInputStream in=new FileInputStream(store.file); OutputStream out=c.getContentResolver().openOutputStream(uri)){
            byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
        }
        return name;
    }
}
