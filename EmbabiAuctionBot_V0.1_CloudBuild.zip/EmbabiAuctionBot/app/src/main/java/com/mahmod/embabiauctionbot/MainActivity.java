package com.mahmod.embabiauctionbot;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Embabi Auction Bot");

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(22), dp(18), dp(22));
        scroll.addView(box);

        TextView title = new TextView(this);
        title.setText("Embabi Auction Bot — V0.1");
        title.setTextSize(26);
        title.setTextColor(Color.rgb(12,36,71));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0,0,0,dp(14));
        box.addView(title);

        TextView help = new TextView(this);
        help.setText("نسخة تجريبية للموبايل نفسه بدون Root.\n" +
                "ابدأ أولاً بالوضع التجريبي للتأكد من قراءة الـ Rating والسعر، ثم شغّل Auto.\n" +
                "التطبيق لا يكتب أرقاماً: المزايدة تتم بزر + ثم تأكيد/تخطي.");
        help.setTextSize(17);
        help.setTextColor(Color.DKGRAY);
        help.setPadding(0,0,0,dp(16));
        box.addView(help);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextColor(Color.BLACK);
        status.setPadding(dp(12),dp(12),dp(12),dp(12));
        box.addView(status);

        addButton(box, "1) تفعيل Accessibility", v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        addButton(box, "ابدأ DRY RUN من الشاشة الرئيسية", v -> {
            AuctionBotService s = AuctionBotService.getInstance();
            if (s == null) {
                toast("فعّل Accessibility للتطبيق أولاً.");
                return;
            }
            s.startBot(false, true);
            toast("DRY RUN بدأ. لن يضغط داخل المزاد.");
        });

        addButton(box, "ابدأ AUTO من الشاشة الرئيسية", v -> {
            AuctionBotService s = AuctionBotService.getInstance();
            if (s == null) {
                toast("فعّل Accessibility للتطبيق أولاً.");
                return;
            }
            s.startBot(true, true);
            toast("AUTO بدأ.");
        });

        addButton(box, "إيقاف / Pause", v -> {
            AuctionBotService s = AuctionBotService.getInstance();
            if (s != null) s.stopBot();
            toast("تم الإيقاف.");
        });

        addButton(box, "تصدير سجل اللعب CSV إلى Downloads", v -> {
            try {
                String name = LogStore.exportCsvToDownloads(this);
                toast("تم التصدير: " + name);
            } catch (Exception e) {
                toast("فشل التصدير: " + e.getMessage());
            }
        });

        addButton(box, "مسح بيانات التعلم", v -> {
            new LearningStore(this).reset();
            new LogStore(this).reset();
            toast("تم مسح بيانات التعلم والسجل.");
        });

        TextView notes = new TextView(this);
        notes.setText("\nقواعد V0.1:\n" +
                "• ترتيب المراكز: GK → DEF → CM → CM → ST.\n" +
                "• لا ميزانية للمدرب؛ الميزانية فقط للجولات المتبقية.\n" +
                "• عند تصدر المنافس، المزايدة العادية = أقل زيادة ممكنة.\n" +
                "• يتعلم احتمال أن يكون اللاعب المجاني أفضل من لاعب المزاد.\n" +
                "• لو القراءة غير مؤكدة، يتوقف عن الضغط بدل المخاطرة.");
        notes.setTextSize(16);
        notes.setTextColor(Color.DKGRAY);
        box.addView(notes);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AuctionBotService s = AuctionBotService.getInstance();
        status.setText(s == null ?
                "الحالة: Accessibility غير متصل." :
                "الحالة: Accessibility متصل. افتح اللعبة ثم اختر DRY RUN أو AUTO.");
    }

    private void addButton(LinearLayout box, String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
        lp.setMargins(0, dp(5), 0, dp(5));
        box.addView(b, lp);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
