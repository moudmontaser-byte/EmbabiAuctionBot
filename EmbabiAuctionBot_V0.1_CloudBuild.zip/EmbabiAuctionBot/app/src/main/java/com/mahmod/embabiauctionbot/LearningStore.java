package com.mahmod.embabiauctionbot;

import android.content.Context;
import android.content.SharedPreferences;

public class LearningStore {
    private final SharedPreferences p;
    public LearningStore(Context c){p=c.getSharedPreferences("learning",Context.MODE_PRIVATE);}

    private String key(int round,int rating){return "r"+round+"_b"+(rating/3);}

    public void observe(int round,int auctionRating,int freeRating){
        if(round<1||auctionRating<60||freeRating<60)return;
        String k=key(round,auctionRating);
        int n=p.getInt(k+"_n",0);
        int u=p.getInt(k+"_u",0);
        int sum=p.getInt(k+"_sum",0);
        p.edit().putInt(k+"_n",n+1)
                .putInt(k+"_u",u+(freeRating>auctionRating?1:0))
                .putInt(k+"_sum",sum+freeRating)
                .apply();
    }

    public double upgradeProbability(int round,int rating){
        String k=key(round,rating);
        int n=p.getInt(k+"_n",0), u=p.getInt(k+"_u",0);
        // Weak prior: about 1 upgrade in 5 rounds until our own data dominates.
        return (u+1.0)/(n+5.0);
    }

    public double expectedFreeRating(int round,int rating){
        String k=key(round,rating);
        int n=p.getInt(k+"_n",0), sum=p.getInt(k+"_sum",0);
        return n==0?Math.max(70,rating-6):(double)sum/n;
    }

    public void reset(){p.edit().clear().apply();}
}
