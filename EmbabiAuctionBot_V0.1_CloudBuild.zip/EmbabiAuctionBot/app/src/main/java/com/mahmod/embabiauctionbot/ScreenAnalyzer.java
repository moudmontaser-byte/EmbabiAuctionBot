package com.mahmod.embabiauctionbot;

import android.graphics.Bitmap;
import android.graphics.Rect;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreenAnalyzer {
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private static final Pattern INT = Pattern.compile("(?<!\\d)(\\d{1,3})(?!\\d)");
    private static final Pattern ROUND = Pattern.compile("([1-5])\\s*[/\\|]\\s*5");

    public interface Callback { void onResult(AuctionSnapshot s, List<Token> tokens); }

    public static class Token {
        public String text;
        public Rect box;
        public Token(String t, Rect r){ text=t; box=r; }
        public int cx(){return box.centerX();}
        public int cy(){return box.centerY();}
    }

    public void analyze(Bitmap bitmap, Callback cb) {
        InputImage image = InputImage.fromBitmap(bitmap,0);
        recognizer.process(image)
                .addOnSuccessListener(text -> {
                    List<Token> tokens = flatten(text);
                    AuctionSnapshot s = parse(bitmap,tokens);
                    cb.onResult(s,tokens);
                })
                .addOnFailureListener(e -> cb.onResult(new AuctionSnapshot(), new ArrayList<>()));
    }

    private List<Token> flatten(Text text) {
        List<Token> out = new ArrayList<>();
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                if(line.getBoundingBox()!=null) out.add(new Token(line.getText(), line.getBoundingBox()));
                for (Text.Element el : line.getElements()) {
                    if(el.getBoundingBox()!=null) out.add(new Token(el.getText(), el.getBoundingBox()));
                }
            }
        }
        return out;
    }

    private AuctionSnapshot parse(Bitmap b, List<Token> tokens) {
        int w=b.getWidth(), h=b.getHeight();
        AuctionSnapshot s = new AuctionSnapshot();
        s.round = readRound(tokens, ScreenGeometry.roundRoi(w,h));
        s.ownBalance = readNumber(tokens, ScreenGeometry.ownBalanceRoi(w,h), 0,100);
        s.oppBalance = readNumber(tokens, ScreenGeometry.oppBalanceRoi(w,h), 0,100);
        s.rating = readNumber(tokens, ScreenGeometry.ratingRoi(w,h), 60,99);
        s.bid = readNumber(tokens, ScreenGeometry.bidRoi(w,h), 0,100);

        float confirmGreen = ImageUtil.greenRatio(b, ScreenGeometry.confirmRoi(w,h));
        s.confirmActive = confirmGreen > 0.10f;

        Rect leader = ScreenGeometry.leaderRoi(w,h);
        float lg = ImageUtil.greenRatio(b, leader);
        float lr = ImageUtil.redRatio(b, leader);
        if(lg > 0.03f && lg > lr*1.15f) s.leader = AuctionSnapshot.Leader.US;
        else if(lr > 0.03f && lr > lg*1.15f) s.leader = AuctionSnapshot.Leader.OPPONENT;
        else s.leader = AuctionSnapshot.Leader.NONE;

        int found=0;
        if(s.round>=1)found++;
        if(s.rating>=60)found++;
        if(s.bid>=0)found++;
        if(s.ownBalance>=0)found++;
        if(s.oppBalance>=0)found++;
        s.confidence = found/5f;
        s.auctionScreen = s.round>=1 && s.rating>=60 && s.confirmActive;
        return s;
    }

    public int readRevealRating(Bitmap b, List<Token> tokens) {
        return readNumber(tokens, ScreenGeometry.revealRatingRoi(b.getWidth(),b.getHeight()),60,99);
    }

    private int readRound(List<Token> tokens, Rect roi) {
        for(Token t:tokens){
            if(!inside(t,roi))continue;
            Matcher m=ROUND.matcher(clean(t.text));
            if(m.find()) return Integer.parseInt(m.group(1));
        }
        return -1;
    }

    private int readNumber(List<Token> tokens, Rect roi, int min, int max) {
        int best=-1, bestArea=-1;
        for(Token t:tokens){
            if(!inside(t,roi))continue;
            String txt=clean(t.text).replace("O","0").replace("o","0");
            Matcher m=INT.matcher(txt);
            while(m.find()){
                try{
                    int v=Integer.parseInt(m.group(1));
                    if(v>=min && v<=max){
                        int area=t.box.width()*t.box.height();
                        if(area>bestArea){best=v;bestArea=area;}
                    }
                }catch(Exception ignored){}
            }
        }
        return best;
    }

    private boolean inside(Token t, Rect r){ return r.contains(t.cx(),t.cy()); }
    private String clean(String s){return s==null?"":s.trim().toUpperCase(Locale.US);}
}
