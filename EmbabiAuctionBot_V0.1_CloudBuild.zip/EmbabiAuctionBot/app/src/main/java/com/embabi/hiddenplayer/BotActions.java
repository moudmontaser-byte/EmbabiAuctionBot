package com.embabi.hiddenplayer;

public final class BotActions {
    private BotActions() {}
    public static final String START = "com.embabi.hiddenplayer.START";
    public static final String STOP = "com.embabi.hiddenplayer.STOP";
    public static final String PAUSE = "com.embabi.hiddenplayer.PAUSE";
    public static final String CAPTURE_REGION = "com.embabi.hiddenplayer.CAPTURE_REGION";
    public static final String TEST_OCR = "com.embabi.hiddenplayer.TEST_OCR";
    public static final String SHOW_OVERLAY = "com.embabi.hiddenplayer.SHOW_OVERLAY";
    public static final String HIDE_OVERLAY = "com.embabi.hiddenplayer.HIDE_OVERLAY";
    public static final String TEMP_HIDE_OVERLAY = "com.embabi.hiddenplayer.TEMP_HIDE_OVERLAY";
    public static final String TEMP_SHOW_OVERLAY = "com.embabi.hiddenplayer.TEMP_SHOW_OVERLAY";
    public static final String STATUS = "com.embabi.hiddenplayer.STATUS";
    public static final String STATE = "com.embabi.hiddenplayer.STATE";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_RATING = "rating";
    public static final String EXTRA_DECISION = "decision";
    public static final String EXTRA_RUNNING = "running";
    public static final String EXTRA_PAUSED = "paused";
    public static final String EXTRA_MATCHES = "matches";
}
