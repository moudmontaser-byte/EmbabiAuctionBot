package com.embabi.hiddenplayer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HiddenPlayerAccessibilityService extends AccessibilityService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private BroadcastReceiver receiver;

    private boolean running=false, paused=false, scanQueued=false, screenshotBusy=false, readingRating=false;
    private boolean actedThisTurn=false, pendingConfirm=false, leftMyTurnAfterAction=false;
    // Post-match state machine:
    // 0 = normal match/navigation
    // 1 = result screen, find/click View lineups/results
    // 2 = lineups opened, find/click Return to main
    // 3 = return requested, wait for Games hub
    // 4 = gray arrow clicked, wait for actual home screen
    private int postMatchStage=0;
    private long postActionNotBefore=0L;
    private boolean stopAfterReturn=false;
    private boolean selectedVisible=false;
    private int selectionTapAttempts=0;
    private long lastSelectionTapAt=0;
    private long startedAt=0;
    private int matchesCompleted=0;
    private String lastStatus="جاهز — افتح Embabi Games وابدأ من اللوحة العائمة";
    private String lastDecision="—";
    private Integer lastRating=null;
    private String targetPackage=null;

    // Floating overlay
    private WindowManager wm;
    private View floatingView;
    private WindowManager.LayoutParams floatingLp;
    private boolean overlayExpanded=true;
    private TextView ovStatus, ovRating, ovDecision, ovThreshold, ovRepeat, ovRunState;
    private RegionSelectView selectorView;
    private View selectorRoot;

    private final Runnable monitor = new Runnable() {
        @Override public void run() {
            if (running && !paused) analyzeCurrentScreen();
            if (running) h.postDelayed(this, 450);
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                String a=i.getAction();
                if(BotActions.START.equals(a)) startBot();
                else if(BotActions.STOP.equals(a)) stopBot("تم إيقاف البوت يدويًا");
                else if(BotActions.PAUSE.equals(a)) togglePause();
                else if(BotActions.CAPTURE_REGION.equals(a)) h.postDelayed(HiddenPlayerAccessibilityService.this::showRegionSelector,450);
                else if(BotActions.TEST_OCR.equals(a)) h.postDelayed(HiddenPlayerAccessibilityService.this::testOcr,450);
                else if(BotActions.SHOW_OVERLAY.equals(a)) showFloatingOverlay(true);
                else if(BotActions.HIDE_OVERLAY.equals(a)) removeFloatingOverlay();
            }
        };
        IntentFilter f=new IntentFilter();
        f.addAction(BotActions.START); f.addAction(BotActions.STOP); f.addAction(BotActions.PAUSE);
        f.addAction(BotActions.CAPTURE_REGION); f.addAction(BotActions.TEST_OCR);
        f.addAction(BotActions.SHOW_OVERLAY); f.addAction(BotActions.HIDE_OVERLAY);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        showFloatingOverlay(true);
        status(lastStatus);
    }

    @Override public void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        removeFloatingOverlay();
        removeSelector();
        if(receiver!=null) try{unregisterReceiver(receiver);}catch(Exception ignored){}
        recognizer.close();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(running && !paused) queueScan(60);
    }
    @Override public void onInterrupt() { }

    private void startBot(){
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root!=null && root.getPackageName()!=null && !getPackageName().contentEquals(root.getPackageName())) targetPackage=root.getPackageName().toString();
        running=true; paused=false; actedThisTurn=false; pendingConfirm=false; leftMyTurnAfterAction=false;
        postMatchStage=0; postActionNotBefore=0L; stopAfterReturn=false;
        matchesCompleted=0; startedAt=System.currentTimeMillis(); lastRating=null; lastDecision="—";
        selectedVisible=false; selectionTapAttempts=0; lastSelectionTapAt=0;
        h.removeCallbacks(monitor); h.post(monitor);
        status("بدأ التشغيل ✓ — أراقب شاشة اللعبة"); refreshOverlay(); analyzeCurrentScreen();
    }

    private void stopBot(String s){
        running=false;paused=false;pendingConfirm=false;readingRating=false;
        selectionTapAttempts=0;lastSelectionTapAt=0;
        h.removeCallbacks(monitor);targetPackage=null;status(s);refreshOverlay();
    }

    private void togglePause(){
        if(!running){ status("البوت غير مشغل — اضغط START أولاً"); return; }
        paused=!paused;
        status(paused?"إيقاف مؤقت — المراقبة متوقفة":"استئناف المراقبة…");
        refreshOverlay(); if(!paused) analyzeCurrentScreen();
    }

    private void queueScan(long delay){
        if(scanQueued)return; scanQueued=true;
        h.postDelayed(()->{scanQueued=false; if(running&&!paused) analyzeCurrentScreen();},delay);
    }

    private boolean isTargetScreen(AccessibilityNodeInfo root){
        if(root==null) return false;
        CharSequence p=root.getPackageName();
        if(p==null) return true;
        if(getPackageName().contentEquals(p)) return false;
        if(targetPackage==null){ targetPackage=p.toString(); return true; }
        return targetPackage.contentEquals(p);
    }

    private void analyzeCurrentScreen(){
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null){ status("أراقب الشاشة… في انتظار اللعبة"); return; }
        if(!isTargetScreen(root)){ status("البوت شغال — ارجع إلى Embabi Games"); return; }
        String all=normalize(collectText(root));
        long now=System.currentTimeMillis();

        // -------- Strict post-match state machine --------
        // Never press the gray arrow merely because it exists. It is only legal in stage 3,
        // after we successfully clicked Return to main and then positively recognized Games hub.
        boolean postMatchMarker = containsAny(all,
                "نهاية المباراه","نهاية المباراة","تقدم المباراه","تقدم المباراة",
                "لحظات مباشره","لحظات مباشرة","ملخص المباراه","ملخص المباراة",
                "رجل المباراه","رجل المباراة","الاهداف والكروت","الأهداف والكروت",
                "عرض التشكيلات","عرض النتائج");

        if(postMatchStage==0 && postMatchMarker){
            postMatchStage=1;
            pendingConfirm=false; actedThisTurn=false; leftMyTurnAfterAction=false;
            status("انتهت المباراة — أنزل حتى زر عرض التشكيلات/النتائج");
        }

        if(postMatchStage>0){
            pendingConfirm=false; actedThisTurn=false;
            if(now<postActionNotBefore){ status("أنتظر انتقال الشاشة…"); return; }

            if(postMatchStage==1){
                AccessibilityNodeInfo n=findVisibleTextAny(root,"عرض التشكيلات","عرض النتائج");
                if(n!=null){
                    status("وجدت عرض التشكيلات/النتائج — أضغط الزر");
                    if(clickNode(n)){
                        postMatchStage=2;
                        postActionNotBefore=now+900;
                        queueScan(950);
                    }
                    return;
                }
                status("نهاية المباراة — Swipe لأسفل الصفحة حتى عرض التشكيلات/النتائج");
                swipePageDown();
                return;
            }

            if(postMatchStage==2){
                AccessibilityNodeInfo n=findVisibleTextAny(root,"العوده للرئيسيه","العودة للرئيسية");
                if(n!=null){
                    status("وجدت العودة للرئيسية — أضغطها الآن");
                    if(clickNode(n)){
                        onMatchCompleted();
                        postMatchStage=3;
                        postActionNotBefore=now+700;
                        queueScan(760);
                    }
                    return;
                }
                status("بعد عرض التشكيلات — Swipe لأسفل حتى العودة للرئيسية");
                swipePageDown();
                return;
            }

            if(postMatchStage==3){
                // Positive ID of the Games hub from the video: title + the two game cards.
                boolean gamesHub = containsAny(all,"الالعاب","الألعاب")
                        && containsAny(all,"اللاعب الخفي")
                        && containsAny(all,"المزاد");
                if(gamesHub && !postMatchMarker){
                    status("صفحة الألعاب تأكدت ✓ — الآن فقط أضغط السهم الرمادي");
                    tapGrayGamesArrow();
                    postMatchStage=4;
                    postActionNotBefore=now+650;
                    queueScan(720);
                } else {
                    status("ضغطت العودة للرئيسية — أنتظر صفحة الألعاب؛ السهم الرمادي ممنوع الآن");
                }
                return;
            }

            if(postMatchStage==4){
                if(containsAny(all,"العب الان","العب الآن")){
                    if(stopAfterReturn){
                        postMatchStage=0;
                        stopBot("اكتملت دورة التكرار ✓ — عدنا للرئيسية");
                        return;
                    }
                    postMatchStage=0;
                    status("الرئيسية جاهزة — أبدأ دورة لاعب خفي جديدة");
                    clickTextAny(root,"العب الان","العب الآن");
                } else {
                    status("ضغطت سهم الألعاب — أنتظر الصفحة الرئيسية");
                }
                return;
            }
        }

        // -------- Normal navigation on the NEW interface --------
        if(containsAny(all,"هاتلي منافس","هات لي منافس")){
            status("جاهز للبحث — أضغط هاتلي منافس"); clickTextAny(root,"هاتلي منافس","هات لي منافس"); return;
        }
        if(containsAny(all,"اختر الكارت","اختار الكارت") && containsAny(all,"1 ضد 1","1ضد1","تحدي")){
            status("مود اللاعب الخفي جاهز — أضغط العب"); clickBestPlayButton(root); return;
        }
        if(containsAny(all,"الالعاب","الألعاب") && containsAny(all,"اللاعب الخفي") && !containsAny(all,"اختر الكارت","اختار الكارت")){
            status("صفحة الألعاب — أفتح اللاعب الخفي"); clickTextAny(root,"اللاعب الخفي"); return;
        }
        if(containsAny(all,"العب الان","العب الآن") && !containsAny(all,"اختر الكارت","اختار الكارت")){
            status("الصفحة الرئيسية — أضغط العب الآن"); clickTextAny(root,"العب الان","العب الآن"); return;
        }

        // -------- Match turns --------
        boolean opponentTurn = containsAny(all,"خصمك يختار","خصمك يقرر","خصمك يختار اللاعب","خصمك اختار","خصمك يقرر اللاعب الخفي");
        boolean myTurn = containsAny(all,"اختر اللاعب","اختار اللاعب","اختر لاعبك","اختار لاعبك","تاكيد الاختيار","تأكيد الاختيار");

        if(opponentTurn && !myTurn){
            if(actedThisTurn && !pendingConfirm) leftMyTurnAfterAction=true;
            if(leftMyTurnAfterAction){actedThisTurn=false;leftMyTurnAfterAction=false;}
            status("دور الخصم — لا ألمس أي شيء، أراقب التغيير"); return;
        }

        if(pendingConfirm){
            AccessibilityNodeInfo c=findVisibleTextAny(root,"تاكيد الاختيار","تأكيد الاختيار");
            if(c!=null && isEnabledClickable(c)){
                status("تم تحديد صورة اللاعب ✓ — أضغط تأكيد الاختيار");
                clickNode(c); pendingConfirm=false; selectionTapAttempts=0; queueScan(180); return;
            }
            long nnow=System.currentTimeMillis();
            if(selectionTapAttempts<4 && nnow-lastSelectionTapAt>560){
                status("زر التأكيد لسه غير فعال — أعيد كليك منتصف صورة اللاعب");
                tapPlayerImage(selectedVisible);
                selectionTapAttempts++; lastSelectionTapAt=nnow; queueScan(330); return;
            }
            status("أنتظر تفعيل زر تأكيد الاختيار…");
            captureBitmap(this::confirmIfYellow); return;
        }

        if(myTurn){
            if(!actedThisTurn && !readingRating){
                status("دوري ✓ — أقرأ تقييم اللاعب اليمين"); readRatingAndChoose();
            } else status("دوري — القرار اتخذ لهذه الجولة، أراقب الانتقال");
            return;
        }

        if(actedThisTurn) leftMyTurnAfterAction=true;
        status("أراقب الشاشة… في انتظار دوري أو دور الخصم");
    }

    private void readRatingAndChoose(){
        if(!Prefs.hasRegion(this)){ choosePlayer(null); return; }
        readingRating=true;
        captureBitmap(bmp->{
            if(bmp==null){readingRating=false;choosePlayer(null);return;}
            RectF n=Prefs.region(this);
            int l=Math.max(0,Math.min(bmp.getWidth()-1,Math.round(n.left*bmp.getWidth())));
            int t=Math.max(0,Math.min(bmp.getHeight()-1,Math.round(n.top*bmp.getHeight())));
            int r=Math.max(l+1,Math.min(bmp.getWidth(),Math.round(n.right*bmp.getWidth())));
            int b=Math.max(t+1,Math.min(bmp.getHeight(),Math.round(n.bottom*bmp.getHeight())));
            Bitmap crop=Bitmap.createBitmap(bmp,l,t,r-l,b-t);
            recognizer.process(InputImage.fromBitmap(crop,0))
                    .addOnSuccessListener(text->{ Integer rating=extractRating(text.getText()); readingRating=false; choosePlayer(rating); crop.recycle(); bmp.recycle(); })
                    .addOnFailureListener(e->{readingRating=false;choosePlayer(null);crop.recycle();bmp.recycle();});
        });
    }

    private Integer extractRating(String raw){
        if(raw==null)return null;
        String s=raw.toUpperCase(Locale.US).replace('O','0').replace('S','5').replace('B','8').replace('I','1').replace('L','1');
        Matcher m=Pattern.compile("(?<!\\d)([5-9]\\d)(?!\\d)").matcher(s);
        Integer best=null;
        while(m.find()){
            try{int v=Integer.parseInt(m.group(1)); if(v>=50&&v<=99){best=v;break;}}catch(Exception ignored){}
        }
        return best;
    }

    private void choosePlayer(Integer rating){
        int threshold=Prefs.threshold(this); boolean visible=rating!=null && rating>=threshold;
        selectedVisible=visible; selectionTapAttempts=1; lastSelectionTapAt=System.currentTimeMillis();
        lastRating=rating; lastDecision=visible?"الظاهر يمين":"الخفي شمال"; refreshOverlay();
        String read=rating==null?"غير مقروء":String.valueOf(rating);
        status("التقييم: "+read+" — أضغط صورة "+(visible?"اللاعب الظاهر يمين":"اللاعب الخفي شمال"));
        tapPlayerImage(visible);
        actedThisTurn=true; pendingConfirm=true; queueScan(260);
    }

    private void tapPlayerImage(boolean visible){
        // Calibrated from the NEW Hidden Player screen supplied by the user.
        // These are the centers of the two actual PLAYER IMAGES, not the rating number or text.
        // Hidden player card center: ~26.5% W, 59.5% H. Visible player card center: ~74.0% W, 59.5% H.
        final float x = visible ? 0.740f : 0.265f;
        final float y = 0.595f;
        status(visible
                ? "الاختيار يمين — كليك مباشر في نص صورة اللاعب الظاهر"
                : "الاختيار شمال — كليك مباشر في نص صورة اللاعب الخفي");
        tapNormalized(x,y);
    }

    private float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    private void confirmIfYellow(Bitmap bmp){
        if(bmp==null||!pendingConfirm)return;
        int w=bmp.getWidth(),hgt=bmp.getHeight(); int l=(int)(.08*w),r=(int)(.92*w),t=(int)(.76*hgt),b=(int)(.91*hgt); int yellow=0,total=0;
        int sx=Math.max(2,(r-l)/90), sy=Math.max(2,(b-t)/30);
        for(int y=t;y<b;y+=sy)for(int x=l;x<r;x+=sx){int c=bmp.getPixel(x,y);int rr=Color.red(c),gg=Color.green(c),bb=Color.blue(c);if(rr>165&&gg>125&&bb<125&&rr>bb*1.35)yellow++;total++;}
        bmp.recycle();
        if(total>0 && yellow/(float)total>.045f){ status("زر التأكيد أصبح فعالًا — أؤكد الاختيار"); tapNormalized(.5f,.835f); pendingConfirm=false; selectionTapAttempts=0; queueScan(220); }
    }

    private void onMatchCompleted(){
        matchesCompleted++;
        String mode=Prefs.repeatMode(this);
        if("count".equals(mode) && matchesCompleted>=Prefs.repeatCount(this)) stopAfterReturn=true;
        if("time".equals(mode) && System.currentTimeMillis()-startedAt>=Prefs.repeatMinutes(this)*60_000L) stopAfterReturn=true;
        refreshOverlay();
        status("انتهت المباراة #"+matchesCompleted+(stopAfterReturn?" — سأعود للرئيسية ثم أتوقف":" — سأبدأ مباراة جديدة"));
    }

    private void testOcr(){
        if(!Prefs.hasRegion(this)){ status("حدد مربع التقييم أولاً من اللوحة العائمة"); return; }
        status("OCR Test… أقرأ المربع المحدد");
        captureBitmap(bmp->{
            if(bmp==null){status("OCR Test: تعذر أخذ لقطة الشاشة");return;}
            RectF n=Prefs.region(this);
            int l=Math.max(0,(int)(n.left*bmp.getWidth())),t=Math.max(0,(int)(n.top*bmp.getHeight()));
            int r=Math.min(bmp.getWidth(),Math.max(l+1,(int)(n.right*bmp.getWidth()))),b=Math.min(bmp.getHeight(),Math.max(t+1,(int)(n.bottom*bmp.getHeight())));
            Bitmap crop=Bitmap.createBitmap(bmp,l,t,r-l,b-t);
            recognizer.process(InputImage.fromBitmap(crop,0)).addOnSuccessListener(tx->{
                Integer v=extractRating(tx.getText()); lastRating=v; lastDecision="اختبار فقط";
                status(v==null?"OCR Test: لم أقرأ تقييمًا — وقت اللعب سأختار الخفي":"OCR Test ✓ قرأ التقييم: "+v);
                refreshOverlay(); crop.recycle(); bmp.recycle();
            }).addOnFailureListener(e->{status("OCR Test: فشل القراءة");crop.recycle();bmp.recycle();});
        });
    }

    private interface BitmapConsumer{void accept(Bitmap b);}
    private void captureBitmap(BitmapConsumer cb){
        if(screenshotBusy){cb.accept(null);return;} screenshotBusy=true;
        try{
            takeScreenshot(0,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    HardwareBuffer hb=result.getHardwareBuffer();
                    Bitmap hw=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                    Bitmap copy=hw==null?null:hw.copy(Bitmap.Config.ARGB_8888,false);
                    hb.close(); screenshotBusy=false; cb.accept(copy);
                }
                @Override public void onFailure(int errorCode){screenshotBusy=false;cb.accept(null);}
            });
        }catch(Exception e){screenshotBusy=false;cb.accept(null);}
    }

    // ---------- Floating control overlay ----------

    private void showFloatingOverlay(boolean expanded){
        overlayExpanded=expanded;
        if(wm==null) wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        removeFloatingOverlay();

        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10),dp(8),dp(10),dp(10));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); box.setBackground(round(Color.argb(244,7,18,32),Color.rgb(84,78,220),16));

        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=ovText("◈ HIDDEN PLAYER",14,Color.WHITE,true); title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        TextView collapse=ovText(expanded?"—":"☰",20,Color.rgb(160,186,255),true); collapse.setGravity(Gravity.CENTER); collapse.setPadding(dp(8),0,dp(8),0);
        TextView close=ovText("×",22,Color.rgb(255,105,125),true); close.setGravity(Gravity.CENTER); close.setPadding(dp(5),0,dp(5),0);
        head.addView(title,new LinearLayout.LayoutParams(0,dp(38),1));
        head.addView(collapse,new LinearLayout.LayoutParams(dp(42),dp(38)));
        head.addView(close,new LinearLayout.LayoutParams(dp(42),dp(38)));
        box.addView(head);

        if(expanded){
            ovRunState=ovText("",12,Color.rgb(0,230,150),true); box.addView(ovRunState);
            ovStatus=ovText(lastStatus,12,Color.rgb(207,219,239),false); ovStatus.setMaxLines(3); ovStatus.setPadding(0,dp(4),0,dp(7)); box.addView(ovStatus);

            LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
            ovRating=chip("Rating: "+(lastRating==null?"—":lastRating),Color.rgb(15,45,67));
            ovDecision=chip("قرار: "+lastDecision,Color.rgb(15,45,67));
            stats.addView(ovRating,new LinearLayout.LayoutParams(0,dp(38),1)); addGap(stats,6); stats.addView(ovDecision,new LinearLayout.LayoutParams(0,dp(38),1)); box.addView(stats);

            LinearLayout controls=new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setPadding(0,dp(7),0,0);
            Button start=ovButton("▶ START",Color.rgb(0,191,120)); Button pause=ovButton("Ⅱ PAUSE",Color.rgb(26,55,82)); Button stop=ovButton("■ STOP",Color.rgb(105,24,42));
            start.setOnClickListener(v->startBot()); pause.setOnClickListener(v->togglePause()); stop.setOnClickListener(v->stopBot("تم إيقاف البوت يدويًا"));
            controls.addView(start,new LinearLayout.LayoutParams(0,dp(43),1));addGap(controls,5);controls.addView(pause,new LinearLayout.LayoutParams(0,dp(43),1));addGap(controls,5);controls.addView(stop,new LinearLayout.LayoutParams(0,dp(43),1));box.addView(controls);

            LinearLayout th=new LinearLayout(this); th.setOrientation(LinearLayout.HORIZONTAL); th.setGravity(Gravity.CENTER_VERTICAL); th.setPadding(0,dp(7),0,0);
            TextView lab=ovText("حد التقييم",12,Color.rgb(166,185,210),true); Button minus=ovButton("−",Color.rgb(24,45,68)); Button plus=ovButton("+",Color.rgb(24,45,68));
            ovThreshold=ovText(String.valueOf(Prefs.threshold(this)),21,Color.WHITE,true);ovThreshold.setGravity(Gravity.CENTER);
            th.addView(lab,new LinearLayout.LayoutParams(0,dp(42),1));th.addView(minus,new LinearLayout.LayoutParams(dp(45),dp(42)));th.addView(ovThreshold,new LinearLayout.LayoutParams(dp(55),dp(42)));th.addView(plus,new LinearLayout.LayoutParams(dp(45),dp(42)));
            minus.setOnClickListener(v->changeThreshold(-1));plus.setOnClickListener(v->changeThreshold(1));box.addView(th);

            LinearLayout rep=new LinearLayout(this);rep.setOrientation(LinearLayout.HORIZONTAL);rep.setPadding(0,dp(6),0,0);
            Button inf=ovButton("∞",Color.rgb(63,45,151));Button cnt=ovButton("#",Color.rgb(26,55,82));Button tim=ovButton("◷",Color.rgb(26,55,82));
            ovRepeat=ovText(repeatLabel(),12,Color.rgb(186,202,225),true);ovRepeat.setGravity(Gravity.CENTER_VERTICAL);
            inf.setOnClickListener(v->{setRepeatMode("infinite");}); cnt.setOnClickListener(v->{setRepeatMode("count");}); tim.setOnClickListener(v->{setRepeatMode("time");});
            rep.addView(ovRepeat,new LinearLayout.LayoutParams(0,dp(42),1));rep.addView(inf,new LinearLayout.LayoutParams(dp(44),dp(42)));addGap(rep,4);rep.addView(cnt,new LinearLayout.LayoutParams(dp(44),dp(42)));addGap(rep,4);rep.addView(tim,new LinearLayout.LayoutParams(dp(44),dp(42)));box.addView(rep);

            LinearLayout adjust=new LinearLayout(this);adjust.setOrientation(LinearLayout.HORIZONTAL);adjust.setPadding(0,dp(5),0,0);
            Button dec=ovButton("− قيمة",Color.rgb(24,45,68));Button inc=ovButton("+ قيمة",Color.rgb(24,45,68));
            dec.setOnClickListener(v->adjustRepeat(-1));inc.setOnClickListener(v->adjustRepeat(1));
            adjust.addView(dec,new LinearLayout.LayoutParams(0,dp(40),1));addGap(adjust,5);adjust.addView(inc,new LinearLayout.LayoutParams(0,dp(40),1));box.addView(adjust);

            LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);tools.setPadding(0,dp(7),0,0);
            Button region=ovButton("▣ حدد المربع",Color.rgb(25,133,220));Button test=ovButton("◎ TEST OCR",Color.rgb(34,58,86));
            region.setOnClickListener(v->showRegionSelector());test.setOnClickListener(v->testOcr());
            tools.addView(region,new LinearLayout.LayoutParams(0,dp(44),1));addGap(tools,5);tools.addView(test,new LinearLayout.LayoutParams(0,dp(44),1));box.addView(tools);
        } else {
            ovStatus=ovText(shortStatus(),11,Color.rgb(205,219,241),true); ovStatus.setGravity(Gravity.CENTER); box.addView(ovStatus,new LinearLayout.LayoutParams(-1,dp(34)));
        }

        collapse.setOnClickListener(v->showFloatingOverlay(!overlayExpanded));
        close.setOnClickListener(v->{
            stopBot("تم إغلاق لوحة التحكم — البوت متوقف");
            removeSelector();
            removeFloatingOverlay();
        });

        floatingLp=new WindowManager.LayoutParams(expanded?dp(310):dp(170),WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        floatingLp.gravity=Gravity.TOP|Gravity.START;
        floatingLp.x=Prefs.get(this).getInt("overlay_x",dp(8));
        floatingLp.y=Prefs.get(this).getInt("overlay_y",dp(80));
        floatingView=box;
        makeDraggable(head);
        try{wm.addView(floatingView,floatingLp);}catch(Exception ignored){}
        refreshOverlay();
    }

    private String shortStatus(){
        if(!running) return "جاهز • اضغط START";
        if(paused) return "PAUSED";
        if(lastRating!=null) return "R "+lastRating+" • "+lastDecision;
        return "مراقبة الشاشة…";
    }

    private void makeDraggable(View handle){
        handle.setOnTouchListener(new View.OnTouchListener(){
            int sx,sy;float dx,dy;boolean moved;
            @Override public boolean onTouch(View v,MotionEvent e){
                if(floatingLp==null)return false;
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=floatingLp.x;sy=floatingLp.y;dx=e.getRawX();dy=e.getRawY();moved=false;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){int nx=sx+(int)(e.getRawX()-dx),ny=sy+(int)(e.getRawY()-dy);if(Math.abs(nx-sx)>4||Math.abs(ny-sy)>4)moved=true;floatingLp.x=Math.max(0,nx);floatingLp.y=Math.max(0,ny);try{wm.updateViewLayout(floatingView,floatingLp);}catch(Exception ignored){}return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){Prefs.get(HiddenPlayerAccessibilityService.this).edit().putInt("overlay_x",floatingLp.x).putInt("overlay_y",floatingLp.y).apply(); if(!moved)showFloatingOverlay(!overlayExpanded);return true;}return false;
            }
        });
    }

    private void changeThreshold(int delta){
        int v=Math.max(50,Math.min(99,Prefs.threshold(this)+delta));Prefs.get(this).edit().putInt(Prefs.THRESHOLD,v).apply();refreshOverlay();status("حد التقييم أصبح "+v);
    }
    private void setRepeatMode(String mode){Prefs.get(this).edit().putString(Prefs.REPEAT_MODE,mode).apply();refreshOverlay();status("وضع التكرار: "+repeatLabel());}
    private void adjustRepeat(int dir){
        String m=Prefs.repeatMode(this); if("infinite".equals(m)){status("الوضع لا نهائي — لا توجد قيمة للتعديل");return;}
        if("count".equals(m)){int v=Math.max(1,Prefs.repeatCount(this)+dir);Prefs.get(this).edit().putInt(Prefs.REPEAT_COUNT,v).apply();}
        else {int step=5;int v=Math.max(5,Prefs.repeatMinutes(this)+dir*step);Prefs.get(this).edit().putInt(Prefs.REPEAT_MINUTES,v).apply();}
        refreshOverlay();
    }
    private String repeatLabel(){String m=Prefs.repeatMode(this);if("count".equals(m))return "التكرار: "+Prefs.repeatCount(this)+" مباراة";if("time".equals(m))return "التكرار: "+Prefs.repeatMinutes(this)+" دقيقة";return "التكرار: لا نهائي ∞";}

    private void refreshOverlay(){
        h.post(()->{
            if(ovStatus!=null)ovStatus.setText(overlayExpanded?lastStatus:shortStatus());
            if(ovRating!=null)ovRating.setText("Rating: "+(lastRating==null?"—":lastRating));
            if(ovDecision!=null)ovDecision.setText("قرار: "+lastDecision);
            if(ovThreshold!=null)ovThreshold.setText(String.valueOf(Prefs.threshold(this)));
            if(ovRepeat!=null)ovRepeat.setText(repeatLabel());
            if(ovRunState!=null){ovRunState.setText(!running?"● جاهز":paused?"● متوقف مؤقتًا":"● يعمل • Match "+(matchesCompleted+1));ovRunState.setTextColor(!running?Color.rgb(120,160,190):paused?Color.rgb(255,195,75):Color.rgb(0,230,150));}
        });
    }

    private void removeFloatingOverlay(){
        if(floatingView!=null&&wm!=null)try{wm.removeView(floatingView);}catch(Exception ignored){}
        floatingView=null;ovStatus=null;ovRating=null;ovDecision=null;ovThreshold=null;ovRepeat=null;ovRunState=null;
    }

    private void showRegionSelector(){
        if(wm==null)wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        removeSelector();
        removeFloatingOverlay();
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.TRANSPARENT);
        selectorView=new RegionSelectView(this);root.addView(selectorView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setPadding(dp(12),dp(8),dp(12),dp(8));bar.setBackgroundColor(Color.argb(235,6,18,31));
        Button cancel=ovButton("إلغاء",Color.rgb(58,66,80));Button save=ovButton("حفظ مربع التقييم ✓",Color.rgb(26,145,235));
        cancel.setOnClickListener(v->{removeSelector();showFloatingOverlay(true);status("تم إلغاء تحديد المربع");});
        save.setOnClickListener(v->{RectF n=selectorView.getNormalizedSelection();if(n==null||n.width()<.025f||n.height()<.02f){Toast.makeText(this,"اسحب مربعًا حول تقييم اللاعب اليمين",Toast.LENGTH_SHORT).show();return;}Prefs.saveRegion(this,n);removeSelector();showFloatingOverlay(true);status(String.format(Locale.US,"تم حفظ مربع التقييم ✓ X %.0f–%.0f%% Y %.0f–%.0f%%",n.left*100,n.right*100,n.top*100,n.bottom*100));});
        bar.addView(cancel,new LinearLayout.LayoutParams(0,dp(48),1));addGap(bar,7);bar.addView(save,new LinearLayout.LayoutParams(0,dp(48),2));
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(66),Gravity.BOTTOM);root.addView(bar,bp);
        selectorRoot=root;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;
        try{wm.addView(root,lp);status("حدد مربعًا حول رقم تقييم اللاعب اليمين ثم اضغط حفظ");}catch(Exception e){selectorRoot=null;showFloatingOverlay(true);status("تعذر فتح تحديد المربع");}
    }

    private void removeSelector(){if(selectorRoot!=null&&wm!=null)try{wm.removeView(selectorRoot);}catch(Exception ignored){}selectorRoot=null;selectorView=null;}

    private class RegionSelectView extends View{
        Paint border=new Paint(3),shade=new Paint(3),label=new Paint(3),cross=new Paint(3);RectF sel=new RectF();float downX,downY;boolean moving=false;float offX,offY;
        RegionSelectView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);border.setStyle(Paint.Style.STROKE);border.setStrokeWidth(dp(3));border.setColor(Color.rgb(40,195,255));shade.setColor(Color.argb(105,0,0,0));label.setColor(Color.WHITE);label.setTextSize(dp(14));label.setTypeface(Typeface.DEFAULT_BOLD);cross.setColor(Color.rgb(40,195,255));cross.setStrokeWidth(dp(2));RectF n=Prefs.region(c);int w=getResources().getDisplayMetrics().widthPixels,hh=getResources().getDisplayMetrics().heightPixels;sel.set(n.left*w,n.top*hh,n.right*w,n.bottom*hh);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),hh=getHeight();c.drawRect(0,0,w,sel.top,shade);c.drawRect(0,sel.bottom,w,hh,shade);c.drawRect(0,sel.top,sel.left,sel.bottom,shade);c.drawRect(sel.right,sel.top,w,sel.bottom,shade);c.drawRoundRect(sel,dp(9),dp(9),border);c.drawText("RATING OCR",sel.left+dp(8),Math.max(dp(22),sel.top-dp(8)),label);float cx=sel.centerX(),cy=sel.centerY();c.drawLine(cx-dp(9),cy,cx+dp(9),cy,cross);c.drawLine(cx,cy-dp(9),cx,cy+dp(9),cross);}
        @Override public boolean onTouchEvent(MotionEvent e){float x=Math.max(0,Math.min(getWidth(),e.getX())),y=Math.max(0,Math.min(getHeight()-dp(70),e.getY()));if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;if(sel.contains(x,y)){moving=true;offX=x-sel.left;offY=y-sel.top;}else{moving=false;sel.set(x,y,x+1,y+1);}invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){if(moving){float ww=sel.width(),hh=sel.height();float l=x-offX,t=y-offY;l=Math.max(0,Math.min(getWidth()-ww,l));t=Math.max(0,Math.min(getHeight()-dp(70)-hh,t));sel.set(l,t,l+ww,t+hh);}else{sel.set(Math.min(downX,x),Math.min(downY,y),Math.max(downX,x),Math.max(downY,y));}invalidate();return true;}return true;}
        RectF getNormalizedSelection(){if(getWidth()<=0||getHeight()<=0)return null;return new RectF(sel.left/getWidth(),sel.top/getHeight(),sel.right/getWidth(),sel.bottom/getHeight());}
    }


    private TextView ovText(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView chip(String s,int fill){TextView t=ovText(s,11,Color.rgb(218,229,245),true);t.setGravity(Gravity.CENTER);t.setBackground(round(fill,Color.rgb(45,73,103),10));return t;}
    private Button ovButton(String s,int fill){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextSize(11);b.setTextColor(Color.WHITE);b.setPadding(dp(4),0,dp(4),0);b.setBackground(round(fill,Color.rgb(Math.min(255,Color.red(fill)+25),Math.min(255,Color.green(fill)+25),Math.min(255,Color.blue(fill)+25)),10));return b;}
    private void addGap(LinearLayout l,int d){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(dp(d),1));}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    // ---------- Accessibility helpers ----------

    private String collectText(AccessibilityNodeInfo root){ StringBuilder sb=new StringBuilder(); collect(root,sb,0); return sb.toString(); }
    private void collect(AccessibilityNodeInfo n,StringBuilder sb,int depth){ if(n==null||depth>40)return; CharSequence t=n.getText(),d=n.getContentDescription(); if(t!=null)sb.append(' ').append(t); if(d!=null)sb.append(' ').append(d); for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),sb,depth+1); }
    private String normalize(String s){ if(s==null)return""; s=Normalizer.normalize(s,Normalizer.Form.NFKD).replaceAll("[\\u064B-\\u065F\\u0670]",""); return s.replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ة','ه').replace('ى','ي').replace('ؤ','و').replace('ئ','ي').replaceAll("\\s+"," ").trim().toLowerCase(Locale.ROOT); }
    private boolean contains(String all,String q){return all.contains(normalize(q));}
    private boolean containsAny(String all,String...qs){for(String q:qs)if(contains(all,q))return true;return false;}
    private AccessibilityNodeInfo findTextAny(AccessibilityNodeInfo root,String...qs){for(String q:qs){AccessibilityNodeInfo n=findText(root,q);if(n!=null)return n;}return null;}
    private AccessibilityNodeInfo findVisibleTextAny(AccessibilityNodeInfo root,String...qs){for(String q:qs){AccessibilityNodeInfo n=findVisibleText(root,q);if(n!=null)return n;}return null;}
    private AccessibilityNodeInfo findText(AccessibilityNodeInfo root,String q){ return findTextRec(root,normalize(q),0); }
    private AccessibilityNodeInfo findVisibleText(AccessibilityNodeInfo root,String q){ return findVisibleTextRec(root,normalize(q),0); }
    private AccessibilityNodeInfo findTextRec(AccessibilityNodeInfo n,String q,int depth){ if(n==null||depth>40)return null; String s=normalize(((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString()))); if(s.contains(q))return n; for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findTextRec(n.getChild(i),q,depth+1);if(r!=null)return r;} return null; }
    private AccessibilityNodeInfo findVisibleTextRec(AccessibilityNodeInfo n,String q,int depth){
        if(n==null||depth>40)return null;
        String s=normalize(((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString())));
        if(s.contains(q) && nodeOnScreen(n)) return n;
        for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findVisibleTextRec(n.getChild(i),q,depth+1);if(r!=null)return r;}
        return null;
    }
    private boolean nodeOnScreen(AccessibilityNodeInfo n){
        if(n==null || !n.isVisibleToUser()) return false;
        Rect r=new Rect(); n.getBoundsInScreen(r);
        int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;
        return !r.isEmpty() && r.right>0 && r.left<w && r.bottom>0 && r.top<hgt && r.centerY()>dp(40) && r.centerY()<hgt-dp(35);
    }
    private boolean clickTextAny(AccessibilityNodeInfo root,String...qs){AccessibilityNodeInfo n=findVisibleTextAny(root,qs);return n!=null&&clickNode(n);}
    private boolean clickNode(AccessibilityNodeInfo n){
        AccessibilityNodeInfo cur=n;
        for(int i=0;i<7&&cur!=null;i++,cur=cur.getParent()){
            if(cur.isClickable()&&cur.isEnabled()){
                try{ if(cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; }catch(Exception ignored){}
            }
        }
        Rect r=new Rect();n.getBoundsInScreen(r);
        if(!r.isEmpty() && nodeOnScreen(n)){tapPx(r.centerX(),r.centerY());return true;}
        return false;
    }
    private boolean isEnabledClickable(AccessibilityNodeInfo n){AccessibilityNodeInfo c=n;for(int i=0;i<6&&c!=null;i++,c=c.getParent())if(c.isClickable()&&c.isEnabled())return true;return false;}
    private void clickBestPlayButton(AccessibilityNodeInfo root){AccessibilityNodeInfo n=findVisibleTextAny(root,"العب","ابدأ");if(n!=null){Rect r=new Rect();n.getBoundsInScreen(r);if(r.centerY()>getResources().getDisplayMetrics().heightPixels*.50f){clickNode(n);return;}}tapNormalized(.5f,.88f);}

    // The gray arrow is ONLY used after strict recognition of the Games hub.
    // Its center is stable at the top-right in the new UI shown in the user's video.
    private void tapGrayGamesArrow(){ tapNormalized(.890f,.078f); }

    // Real swipe gesture: WebView pages often ignore ACTION_SCROLL_FORWARD.
    private void swipePageDown(){
        int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;
        float x=.82f*w, sy=.82f*hgt, ey=.34f*hgt;
        Path p=new Path(); p.moveTo(x,sy); p.lineTo(x,ey);
        GestureDescription.StrokeDescription st=new GestureDescription.StrokeDescription(p,0,420);
        GestureDescription g=new GestureDescription.Builder().addStroke(st).build();
        dispatchGesture(g,null,null);
        queueScan(520);
    }

    private void tapNormalized(float nx,float ny){int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;tapPx(Math.round(nx*w),Math.round(ny*hgt));}
    private void tapPx(float x,float y){Path p=new Path();p.moveTo(x,y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,120);GestureDescription g=new GestureDescription.Builder().addStroke(s).build();dispatchGesture(g,null,null);}

    private void status(String s){
        if(s==null)s=""; if(s.equals(lastStatus)){refreshOverlay();return;} lastStatus=s; refreshOverlay();
        Intent i=new Intent(BotActions.STATUS).setPackage(getPackageName());i.putExtra(BotActions.EXTRA_STATUS,s);sendBroadcast(i);
    }
}
