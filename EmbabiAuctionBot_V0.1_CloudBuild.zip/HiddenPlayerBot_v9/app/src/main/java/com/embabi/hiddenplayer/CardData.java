package com.embabi.hiddenplayer;

import java.util.*;
import java.util.regex.*;

public final class CardData {
    public final String name;
    public final Integer rating;
    public final String raw;

    public CardData(String name, Integer rating, String raw){
        this.name=name==null?"":name.trim();
        this.rating=rating;
        this.raw=raw==null?"":raw;
    }

    public boolean hasValidRating(){ return rating!=null && rating>=50 && rating<=99; }

    public static CardData parse(String raw){
        String src=raw==null?"":raw;
        String normalized=normalizeDigits(src).replace('\u00A0',' ');
        Integer rating=null;
        Matcher m=Pattern.compile("(?<!\\d)([5-9]\\d)(?!\\d)").matcher(normalized.toUpperCase(Locale.US)
                .replace('O','0').replace('S','5').replace('B','8').replace('I','1').replace('L','1'));
        while(m.find()){
            try{ int v=Integer.parseInt(m.group(1)); if(v>=50&&v<=99){rating=v;break;} }catch(Exception ignored){}
        }

        String best="";
        for(String line:normalized.split("[\\r\\n]+")){
            String s=line.trim().replaceAll("\\s+"," ");
            if(s.length()<2 || s.length()>36) continue;
            if(s.matches(".*\\d.*")) continue;
            String u=s.toUpperCase(Locale.US);
            if(u.contains("RATING")||u.contains("PLAYER")||u.contains("HIDDEN")||u.contains("CONFIRM")||u.contains("ROUND")) continue;
            int letters=0;
            for(int i=0;i<s.length();i++) if(Character.isLetter(s.charAt(i))) letters++;
            if(letters>=2 && letters>best.replaceAll("[^A-Za-z]","").length()) best=s;
        }
        return new CardData(best,rating,src);
    }

    public static String normalizeDigits(String s){
        if(s==null)return "";
        StringBuilder b=new StringBuilder(s.length());
        for(char c:s.toCharArray()){
            if(c>='٠'&&c<='٩') b.append((char)('0'+(c-'٠')));
            else if(c>='۰'&&c<='۹') b.append((char)('0'+(c-'۰')));
            else b.append(c);
        }
        return b.toString();
    }
}
