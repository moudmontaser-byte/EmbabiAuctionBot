package com.embabi.hiddenplayer;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class AnalyticsDb extends SQLiteOpenHelper {
    private static final String DB="embabi_analytics.db";
    private static final int VER=1;

    public static final class Stats {
        public int matches,wins,draws,losses,unknown,rounds,validRounds;
    }
    public static final class Pair {
        public long id,matchId;
        public int round,visible,hidden,opponent,pattern;
        public String visibleName,hiddenName,opponentName,selected,mode,result;
    }

    public AnalyticsDb(Context c){ super(c,DB,null,VER); }

    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE matches(id INTEGER PRIMARY KEY AUTOINCREMENT, started_at INTEGER, ended_at INTEGER DEFAULT 0, result TEXT DEFAULT 'UNKNOWN', pattern_id INTEGER DEFAULT -1, lineup_text TEXT DEFAULT '', opponent_ocr TEXT DEFAULT '', opponent_strength REAL DEFAULT -1)");
        db.execSQL("CREATE TABLE rounds(id INTEGER PRIMARY KEY AUTOINCREMENT, match_id INTEGER, round_no INTEGER, ts INTEGER, visible_name TEXT DEFAULT '', visible_rating INTEGER DEFAULT -1, hidden_name TEXT DEFAULT '', hidden_rating INTEGER DEFAULT -1, opponent_name TEXT DEFAULT '', opponent_rating INTEGER DEFAULT -1, selected_side TEXT DEFAULT '', threshold_used INTEGER DEFAULT -1, decision_mode TEXT DEFAULT 'manual', predicted_pattern INTEGER DEFAULT -1, ocr_visible TEXT DEFAULT '', ocr_hidden TEXT DEFAULT '', valid INTEGER DEFAULT 0, FOREIGN KEY(match_id) REFERENCES matches(id))");
        db.execSQL("CREATE INDEX idx_rounds_match ON rounds(match_id)");
        db.execSQL("CREATE INDEX idx_rounds_valid ON rounds(valid,round_no)");
        db.execSQL("CREATE INDEX idx_matches_pattern ON matches(pattern_id)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}

    public synchronized long beginMatch(){
        ContentValues v=new ContentValues();v.put("started_at",System.currentTimeMillis());
        return getWritableDatabase().insert("matches",null,v);
    }

    public synchronized void setMatchResult(long id,String result){
        if(id<=0)return;ContentValues v=new ContentValues();v.put("result",result==null?"UNKNOWN":result);getWritableDatabase().update("matches",v,"id=?",new String[]{String.valueOf(id)});
    }

    public synchronized void appendLineup(long id,String accessText,String opponentOcr){
        if(id<=0)return;
        SQLiteDatabase db=getWritableDatabase();
        Cursor c=db.rawQuery("SELECT lineup_text,opponent_ocr FROM matches WHERE id=?",new String[]{String.valueOf(id)});
        String a="",o="";if(c.moveToFirst()){a=c.getString(0);o=c.getString(1);}c.close();
        if(accessText!=null&&!accessText.isBlank()&&!a.contains(accessText)) a=(a+"\n---\n"+accessText).trim();
        if(opponentOcr!=null&&!opponentOcr.isBlank()&&!o.contains(opponentOcr)) o=(o+"\n---\n"+opponentOcr).trim();
        ContentValues v=new ContentValues();v.put("lineup_text",a);v.put("opponent_ocr",o);double strength=averageRatings(o);if(strength>0)v.put("opponent_strength",strength);db.update("matches",v,"id=?",new String[]{String.valueOf(id)});
    }

    public synchronized void finishMatch(long id,int pattern){
        if(id<=0)return;ContentValues v=new ContentValues();v.put("ended_at",System.currentTimeMillis());v.put("pattern_id",pattern);getWritableDatabase().update("matches",v,"id=?",new String[]{String.valueOf(id)});
    }

    public synchronized long insertRound(long matchId,int round,CardData visible,CardData opponent,String selected,int threshold,String mode,int predictedPattern){
        ContentValues v=new ContentValues();
        v.put("match_id",matchId);v.put("round_no",round);v.put("ts",System.currentTimeMillis());
        v.put("visible_name",visible==null?"":visible.name);v.put("visible_rating",visible==null||visible.rating==null?-1:visible.rating);
        v.put("opponent_name",opponent==null?"":opponent.name);v.put("opponent_rating",opponent==null||opponent.rating==null?-1:opponent.rating);
        v.put("selected_side",selected);v.put("threshold_used",threshold);v.put("decision_mode",mode);v.put("predicted_pattern",predictedPattern);
        v.put("ocr_visible",visible==null?"":visible.raw);v.put("valid",0);
        return getWritableDatabase().insert("rounds",null,v);
    }

    public synchronized void updateHidden(long roundId,CardData hidden){
        if(roundId<=0)return;
        SQLiteDatabase db=getWritableDatabase();
        int vr=-1;Cursor c=db.rawQuery("SELECT visible_rating FROM rounds WHERE id=?",new String[]{String.valueOf(roundId)});if(c.moveToFirst())vr=c.getInt(0);c.close();
        int hr=hidden==null||hidden.rating==null?-1:hidden.rating;
        ContentValues v=new ContentValues();v.put("hidden_name",hidden==null?"":hidden.name);v.put("hidden_rating",hr);v.put("ocr_hidden",hidden==null?"":hidden.raw);v.put("valid",vr>=50&&vr<=99&&hr>=50&&hr<=99?1:0);
        db.update("rounds",v,"id=?",new String[]{String.valueOf(roundId)});
    }

    public synchronized void setPatternForMatch(long matchId,int pattern){
        ContentValues a=new ContentValues();a.put("pattern_id",pattern);getWritableDatabase().update("matches",a,"id=?",new String[]{String.valueOf(matchId)});
    }

    public synchronized Stats stats(){
        Stats s=new Stats();SQLiteDatabase db=getReadableDatabase();
        Cursor c=db.rawQuery("SELECT COUNT(*),SUM(CASE WHEN result='WIN' THEN 1 ELSE 0 END),SUM(CASE WHEN result='DRAW' THEN 1 ELSE 0 END),SUM(CASE WHEN result='LOSS' THEN 1 ELSE 0 END),SUM(CASE WHEN result NOT IN ('WIN','DRAW','LOSS') THEN 1 ELSE 0 END) FROM matches WHERE ended_at>0",null);
        if(c.moveToFirst()){s.matches=c.getInt(0);s.wins=c.getInt(1);s.draws=c.getInt(2);s.losses=c.getInt(3);s.unknown=c.getInt(4);}c.close();
        c=db.rawQuery("SELECT COUNT(*),SUM(valid) FROM rounds",null);if(c.moveToFirst()){s.rounds=c.getInt(0);s.validRounds=c.getInt(1);}c.close();return s;
    }

    public synchronized List<Pair> pairsForRound(int round,Integer pattern,Integer minVisible,Integer maxVisible){
        StringBuilder sql=new StringBuilder("SELECT r.id,r.match_id,r.round_no,r.visible_rating,r.hidden_rating,r.opponent_rating,COALESCE(m.pattern_id,-1),r.visible_name,r.hidden_name,r.opponent_name,r.selected_side,r.decision_mode,m.result FROM rounds r JOIN matches m ON m.id=r.match_id WHERE r.valid=1 AND r.round_no=?");
        List<String> args=new ArrayList<>();args.add(String.valueOf(round));
        if(pattern!=null&&pattern>=0){sql.append(" AND m.pattern_id=?");args.add(String.valueOf(pattern));}
        if(minVisible!=null){sql.append(" AND r.visible_rating>=?");args.add(String.valueOf(minVisible));}
        if(maxVisible!=null){sql.append(" AND r.visible_rating<=?");args.add(String.valueOf(maxVisible));}
        List<Pair> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery(sql.toString(),args.toArray(new String[0]));
        while(c.moveToNext()){Pair p=new Pair();p.id=c.getLong(0);p.matchId=c.getLong(1);p.round=c.getInt(2);p.visible=c.getInt(3);p.hidden=c.getInt(4);p.opponent=c.getInt(5);p.pattern=c.getInt(6);p.visibleName=c.getString(7);p.hiddenName=c.getString(8);p.opponentName=c.getString(9);p.selected=c.getString(10);p.mode=c.getString(11);p.result=c.getString(12);out.add(p);}c.close();return out;
    }

    public synchronized List<Pair> pairsForMatch(long matchId){
        List<Pair> out=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT r.id,r.match_id,r.round_no,r.visible_rating,r.hidden_rating,r.opponent_rating,COALESCE(m.pattern_id,-1),r.visible_name,r.hidden_name,r.opponent_name,r.selected_side,r.decision_mode,m.result FROM rounds r JOIN matches m ON m.id=r.match_id WHERE r.match_id=? AND r.valid=1 ORDER BY r.round_no",new String[]{String.valueOf(matchId)});
        while(c.moveToNext()){Pair p=new Pair();p.id=c.getLong(0);p.matchId=c.getLong(1);p.round=c.getInt(2);p.visible=c.getInt(3);p.hidden=c.getInt(4);p.opponent=c.getInt(5);p.pattern=c.getInt(6);p.visibleName=c.getString(7);p.hiddenName=c.getString(8);p.opponentName=c.getString(9);p.selected=c.getString(10);p.mode=c.getString(11);p.result=c.getString(12);out.add(p);}c.close();return out;
    }

    public synchronized int[] patternCounts(){
        int[] x=new int[16];Cursor c=getReadableDatabase().rawQuery("SELECT pattern_id,COUNT(*) FROM matches WHERE ended_at>0 AND pattern_id BETWEEN 0 AND 15 GROUP BY pattern_id",null);while(c.moveToNext())x[c.getInt(0)]=c.getInt(1);c.close();return x;
    }

    private double averageRatings(String raw){
        if(raw==null)return -1;String s=CardData.normalizeDigits(raw);java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)([5-9]\\d)(?!\\d)").matcher(s);double sum=0;int n=0;while(m.find()){try{int v=Integer.parseInt(m.group(1));if(v>=50&&v<=99){sum+=v;n++;}}catch(Exception ignored){}}return n==0?-1:sum/n;
    }

    public synchronized Cursor exportCursor(){
        return getReadableDatabase().rawQuery("SELECT r.id,r.match_id,r.round_no,r.ts,r.visible_name,r.visible_rating,r.hidden_name,r.hidden_rating,r.opponent_name,r.opponent_rating,r.selected_side,r.threshold_used,r.decision_mode,r.predicted_pattern,r.valid,m.result,m.pattern_id,m.started_at,m.ended_at,m.opponent_strength FROM rounds r LEFT JOIN matches m ON m.id=r.match_id ORDER BY r.id",null);
    }
}
