package com.embabi.hiddenplayer;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.*;

public class AnalyticsActivity extends Activity {
    private AnalyticsDb db;private AnalyticsEngine engine;private TextView report;
    private static final int CREATE_CSV=901;
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new AnalyticsDb(this);engine=new AnalyticsEngine(this,db);build();}
    @Override protected void onResume(){super.onResume();if(report!=null)report.setText(engine.fullReport());}
    private void build(){
        int bg=Color.rgb(5,14,27),white=Color.rgb(244,247,255),muted=Color.rgb(164,184,210),blue=Color.rgb(31,149,255),green=Color.rgb(0,220,136);
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(bg);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(28));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);
        TextView t=new TextView(this);t.setText("◈ EMBABI ANALYTICS");t.setTextColor(white);t.setTextSize(23);t.setTypeface(null,1);root.addView(t);
        TextView sub=new TextView(this);sub.setText("تحليل محلي مستمر • 11 جولة • 16 بصمة نمط محتملة");sub.setTextColor(muted);sub.setTextSize(13);sub.setPadding(0,dp(4),0,dp(14));root.addView(sub);
        report=new TextView(this);report.setText(engine.fullReport());report.setTextColor(Color.rgb(210,224,244));report.setTextSize(14);report.setTextDirection(View.TEXT_DIRECTION_LTR);report.setGravity(Gravity.LEFT);report.setPadding(dp(14),dp(14),dp(14),dp(14));report.setBackgroundColor(Color.rgb(11,27,46));root.addView(report,new LinearLayout.LayoutParams(-1,-2));
        Button export=btn("Export CSV — كل الجولات",blue);export.setOnClickListener(v->createCsv());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.topMargin=dp(12);root.addView(export,p);
        Button resetAll=btn("ضبط حدود 1–11 إلى 85",Color.rgb(35,55,80));resetAll.setOnClickListener(v->{Prefs.setAllRoundThresholds(this,85);Toast.makeText(this,"تم ضبط 11 جولة إلى 85",Toast.LENGTH_SHORT).show();report.setText(engine.fullReport());});LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(-1,dp(50));p2.topMargin=dp(8);root.addView(resetAll,p2);
        setContentView(sc);
    }
    private Button btn(String s,int c){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setBackgroundColor(c);return b;}
    private void createCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"embabi_hidden_player_data.csv");startActivityForResult(i,CREATE_CSV);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==CREATE_CSV&&res==RESULT_OK&&data!=null&&data.getData()!=null)writeCsv(data.getData());}
    private void writeCsv(Uri uri){
        try(OutputStream os=getContentResolver().openOutputStream(uri);BufferedWriter w=new BufferedWriter(new OutputStreamWriter(os))){
            w.write("round_id,match_id,round_no,timestamp,visible_name,visible_rating,hidden_name,hidden_rating,opponent_name,opponent_rating,selected_side,threshold,mode,predicted_pattern,valid,match_result,final_pattern,match_started,match_ended,opponent_strength\n");
            Cursor c=db.exportCursor();while(c.moveToNext()){for(int i=0;i<c.getColumnCount();i++){if(i>0)w.write(',');w.write(csv(c.isNull(i)?"":c.getString(i)));}w.write('\n');}c.close();Toast.makeText(this,"تم تصدير البيانات ✓",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"فشل التصدير: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private String csv(String s){return "\""+s.replace("\"","\"\"").replace("\n"," ")+"\"";}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
