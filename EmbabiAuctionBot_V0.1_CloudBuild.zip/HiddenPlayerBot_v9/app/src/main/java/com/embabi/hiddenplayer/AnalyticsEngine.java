package com.embabi.hiddenplayer;

import android.content.Context;
import java.util.*;

public class AnalyticsEngine {
    public static final int AUTO_UNLOCK_VALID_ROUNDS=1000;
    private final Context c; private final AnalyticsDb db;
    public AnalyticsEngine(Context c,AnalyticsDb db){this.c=c.getApplicationContext();this.db=db;}

    public static final class Decision {
        public boolean visible; public int threshold; public int pattern; public int sample;
        public double expectedHidden; public String reason;
    }

    public boolean autoUnlocked(){return db.stats().validRounds>=AUTO_UNLOCK_VALID_ROUNDS;}

    public int learnedThreshold(int round){
        List<AnalyticsDb.Pair> pairs=db.pairsForRound(round,null,null,null);
        if(pairs.size()<20)return Prefs.roundThreshold(c,round);
        int best=Prefs.roundThreshold(c,round);double bestScore=-1e9;
        for(int t=60;t<=96;t++){
            double sum=0;int n=0;
            for(AnalyticsDb.Pair p:pairs){sum+=(p.visible>=t?p.visible:p.hidden);n++;}
            double score=n==0?-1e9:sum/n;
            if(score>bestScore+.0001){bestScore=score;best=t;}
        }
        return best;
    }

    public Decision decide(long matchId,int round,int visibleRating){
        Decision d=new Decision();d.pattern=inferPartialPattern(matchId);d.threshold=learnedThreshold(round);
        if(!autoUnlocked()){
            d.visible=visibleRating>=Prefs.roundThreshold(c,round);d.reason="AUTO LOCKED — threshold manual";return d;
        }
        List<AnalyticsDb.Pair> local=db.pairsForRound(round,d.pattern>=0?d.pattern:null,Math.max(50,visibleRating-2),Math.min(99,visibleRating+2));
        if(local.size()>=12){
            double h=0;for(AnalyticsDb.Pair p:local)h+=p.hidden;h/=local.size();
            d.sample=local.size();d.expectedHidden=h;d.visible=visibleRating>=h-0.20;
            d.reason="Pattern P"+(d.pattern+1)+" • n="+d.sample+" • hidden EV="+String.format(Locale.US,"%.1f",h);
        }else{
            d.visible=visibleRating>=d.threshold;d.sample=local.size();
            d.reason="Learned R"+round+" threshold="+d.threshold+(d.pattern>=0?" • P"+(d.pattern+1):"");
        }
        return d;
    }

    public int inferPatternForCompletedMatch(long matchId){return fingerprint(db.pairsForMatch(matchId),false);}
    public int inferPartialPattern(long matchId){List<AnalyticsDb.Pair> p=db.pairsForMatch(matchId);if(p.size()<3)return -1;return fingerprint(p,true);}

    private int fingerprint(List<AnalyticsDb.Pair> p,boolean partial){
        if(p.isEmpty())return -1;
        double e=0,m=0,l=0;int en=0,mn=0,ln=0;List<Double> dif=new ArrayList<>();
        for(AnalyticsDb.Pair x:p){double d=x.hidden-x.visible;dif.add(d);if(x.round<=3){e+=d;en++;}else if(x.round<=7){m+=d;mn++;}else{l+=d;ln++;}}
        int bits=0;if(en>0&&e/en>0)bits|=1;if(mn>0&&m/mn>0)bits|=2;if(ln>0&&l/ln>0)bits|=4;
        double mean=0;for(double v:dif)mean+=v;mean/=dif.size();double var=0;for(double v:dif)var+=(v-mean)*(v-mean);var/=dif.size();
        if(Math.sqrt(var)>=4.5)bits|=8;
        return bits;
    }

    public String compactSummary(){
        AnalyticsDb.Stats s=db.stats();StringBuilder b=new StringBuilder();
        b.append("Matches ").append(s.matches).append(" • W ").append(s.wins).append(" • D ").append(s.draws).append(" • L ").append(s.losses).append('\n');
        b.append("Valid rounds ").append(s.validRounds).append('/').append(AUTO_UNLOCK_VALID_ROUNDS).append(autoUnlocked()?" • AUTO UNLOCKED":" • collecting");
        return b.toString();
    }

    public String fullReport(){
        AnalyticsDb.Stats s=db.stats();StringBuilder b=new StringBuilder();
        b.append("EMBABI ADAPTIVE ANALYTICS\n\n");
        b.append("Matches: ").append(s.matches).append("  W:").append(s.wins).append("  D:").append(s.draws).append("  L:").append(s.losses).append("  Unknown:").append(s.unknown).append('\n');
        b.append("Rounds: ").append(s.rounds).append("  Valid for learning: ").append(s.validRounds).append('\n');
        b.append("Auto Learned: ").append(autoUnlocked()?"UNLOCKED":"LOCKED until 1000 valid rounds").append("\n\n");
        b.append("Learned threshold by round\n");
        for(int r=1;r<=11;r++){List<AnalyticsDb.Pair> p=db.pairsForRound(r,null,null,null);b.append(String.format(Locale.US,"R%02d  suggested %d  samples %d\n",r,learnedThreshold(r),p.size()));}
        b.append("\n16 candidate pattern fingerprints\n");int[] pc=db.patternCounts();for(int i=0;i<16;i++)b.append("P").append(i+1).append(": ").append(pc[i]).append(i%4==3?'\n':'\t');
        b.append("\nRating categories (all valid rounds)\n");
        int[][] bands={{50,79},{80,82},{83,84},{85,86},{87,89},{90,92},{93,99}};
        for(int[] z:bands){int n=0,hBetter=0,w=0,l=0,d=0;double gap=0;for(int r=1;r<=11;r++)for(AnalyticsDb.Pair p:db.pairsForRound(r,null,z[0],z[1])){n++;double g=p.hidden-p.visible;gap+=g;if(g>0)hBetter++;if("WIN".equals(p.result))w++;else if("LOSS".equals(p.result))l++;else if("DRAW".equals(p.result))d++;}if(n>0)b.append(String.format(Locale.US,"%d-%d: n=%d  hidden-better=%.1f%%  avg hidden gap=%+.2f  W/D/L=%d/%d/%d\n",z[0],z[1],n,100.0*hBetter/n,gap/n,w,d,l));}

        Map<String,int[]> player=new HashMap<>();Map<String,int[]> opp=new HashMap<>();
        for(int r=1;r<=11;r++)for(AnalyticsDb.Pair p:db.pairsForRound(r,null,null,null)){String chosen="VISIBLE".equals(p.selected)?p.visibleName:p.hiddenName;if(chosen!=null&&!chosen.isBlank()){int[] a=player.computeIfAbsent(chosen.toUpperCase(Locale.US),k->new int[3]);a[0]++;if("WIN".equals(p.result))a[1]++;if("LOSS".equals(p.result))a[2]++;}if(p.opponentName!=null&&!p.opponentName.isBlank()){int[] a=opp.computeIfAbsent(p.opponentName.toUpperCase(Locale.US),k->new int[3]);a[0]++;if("WIN".equals(p.result))a[1]++;if("LOSS".equals(p.result))a[2]++;}}
        b.append("\nSelected-player evidence (min 5 samples)\n");appendTopNames(b,player,true);
        b.append("\nOpponent-player evidence (min 5 samples)\n");appendTopNames(b,opp,false);
        b.append("\nNote: P1-P16 are statistical fingerprints discovered from recorded matches, not a claim that they are the game's internal source-code algorithms. Correlations with wins/losses are evidence, not guaranteed causation.");
        return b.toString();
    }
    private void appendTopNames(StringBuilder b,Map<String,int[]> map,boolean selected){
        List<Map.Entry<String,int[]>> list=new ArrayList<>(map.entrySet());
        list.removeIf(e->e.getValue()[0]<5);
        list.sort((a,z)->Double.compare(scoreName(z.getValue()),scoreName(a.getValue())));
        int lim=Math.min(8,list.size());if(lim==0){b.append("Not enough clean OCR samples yet.\n");return;}
        for(int i=0;i<lim;i++){Map.Entry<String,int[]> e=list.get(i);int[] x=e.getValue();double wr=x[0]==0?0:100.0*x[1]/x[0];b.append(String.format(Locale.US,"%s: n=%d  win-association=%.1f%%  losses=%d\n",e.getKey(),x[0],wr,x[2]));}
    }
    private double scoreName(int[] x){return x[0]<5?-999:(x[1]-x[2])/(double)Math.max(1,x[0]);}

}
