package com.embabi.hiddenplayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.RectF;

public final class Prefs {
    public static final String NAME = "embabi_hidden_player";
    public static final String THRESHOLD = "threshold";
    public static final String REPEAT_MODE = "repeat_mode";
    public static final String REPEAT_COUNT = "repeat_count";
    public static final String REPEAT_MINUTES = "repeat_minutes";
    public static final String REGION_L = "region_l";
    public static final String REGION_T = "region_t";
    public static final String REGION_R = "region_r";
    public static final String REGION_B = "region_b";
    public static final String REGION_SET = "region_set";

    public static final String BOT_WANTED = "bot_wanted";
    public static final String BOT_PAUSED = "bot_paused";
    public static final String OVERLAY_WANTED = "overlay_wanted";
    public static final String LAST_STATUS = "last_status";
    public static final String LAST_RATING = "last_rating";
    public static final String LAST_DECISION = "last_decision";
    public static final String MATCHES_COMPLETED = "matches_completed";
    public static final String BOT_STARTED_AT = "bot_started_at";
    public static final String ACCESS_HEARTBEAT = "access_heartbeat";
    public static final String DECISION_MODE = "decision_mode"; // manual / suggested / auto
    public static final String CURRENT_ROUND = "current_round";
    public static final String LAST_OUTCOME = "last_outcome";
    public static final String CURRENT_MATCH_ID = "current_match_id";
    public static final String CURRENT_ROUND_ROW_ID = "current_round_row_id";

    public static final String REGION_VISIBLE="visible";
    public static final String REGION_HIDDEN="hidden";
    public static final String REGION_OPPONENT="opponent";

    private Prefs() {}

    public static SharedPreferences get(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }

    public static int threshold(Context c) { return get(c).getInt(THRESHOLD, 85); }
    public static String repeatMode(Context c) { return get(c).getString(REPEAT_MODE, "infinite"); }
    public static int repeatCount(Context c) { return Math.max(1, get(c).getInt(REPEAT_COUNT, 10)); }
    public static int repeatMinutes(Context c) { return Math.max(1, get(c).getInt(REPEAT_MINUTES, 60)); }
    public static boolean hasRegion(Context c) { return hasRegion(c,REGION_VISIBLE); }

    public static boolean botWanted(Context c) { return get(c).getBoolean(BOT_WANTED, false); }
    public static boolean botPaused(Context c) { return get(c).getBoolean(BOT_PAUSED, false); }
    public static boolean overlayWanted(Context c) { return get(c).getBoolean(OVERLAY_WANTED, false); }
    public static String lastStatus(Context c) { return get(c).getString(LAST_STATUS, "جاهز — افتح Embabi Games"); }
    public static int lastRating(Context c) { return get(c).getInt(LAST_RATING, -1); }
    public static String lastDecision(Context c) { return get(c).getString(LAST_DECISION, "—"); }
    public static int matchesCompleted(Context c) { return Math.max(0, get(c).getInt(MATCHES_COMPLETED, 0)); }
    public static long botStartedAt(Context c) { return get(c).getLong(BOT_STARTED_AT, 0L); }
    public static long accessHeartbeat(Context c){ return get(c).getLong(ACCESS_HEARTBEAT,0L); }
    public static String decisionMode(Context c){return get(c).getString(DECISION_MODE,"manual");}
    public static int currentRound(Context c){return Math.max(1,Math.min(11,get(c).getInt(CURRENT_ROUND,1)));}
    public static String lastOutcome(Context c){return get(c).getString(LAST_OUTCOME,"UNKNOWN");}
    public static long currentMatchId(Context c){return get(c).getLong(CURRENT_MATCH_ID,-1L);}
    public static long currentRoundRowId(Context c){return get(c).getLong(CURRENT_ROUND_ROW_ID,-1L);}

    public static void setBotWanted(Context c, boolean wanted) { get(c).edit().putBoolean(BOT_WANTED, wanted).apply(); }
    public static void setBotStartedAt(Context c,long when){ get(c).edit().putLong(BOT_STARTED_AT,when).apply(); }
    public static void setAccessHeartbeat(Context c,long when){ get(c).edit().putLong(ACCESS_HEARTBEAT,when).apply(); }
    public static void setBotPaused(Context c, boolean paused) { get(c).edit().putBoolean(BOT_PAUSED, paused).apply(); }
    public static void setOverlayWanted(Context c, boolean wanted) { get(c).edit().putBoolean(OVERLAY_WANTED, wanted).apply(); }
    public static void setDecisionMode(Context c,String mode){ if(!"manual".equals(mode)&&!"suggested".equals(mode)&&!"auto".equals(mode))mode="manual";get(c).edit().putString(DECISION_MODE,mode).apply(); }
    public static void setCurrentRound(Context c,int r){get(c).edit().putInt(CURRENT_ROUND,Math.max(1,Math.min(11,r))).apply();}
    public static void setLastOutcome(Context c,String s){get(c).edit().putString(LAST_OUTCOME,s==null?"UNKNOWN":s).apply();}
    public static void setCurrentMatchId(Context c,long id){get(c).edit().putLong(CURRENT_MATCH_ID,id).apply();}
    public static void setCurrentRoundRowId(Context c,long id){get(c).edit().putLong(CURRENT_ROUND_ROW_ID,id).apply();}
    public static void saveRuntime(Context c, String status, Integer rating, String decision, int matches) {
        SharedPreferences.Editor e=get(c).edit();
        if(status!=null)e.putString(LAST_STATUS,status);
        e.putInt(LAST_RATING,rating==null?-1:rating);
        if(decision!=null)e.putString(LAST_DECISION,decision);
        e.putInt(MATCHES_COMPLETED,Math.max(0,matches));
        e.apply();
    }

    public static int roundThreshold(Context c,int round){
        int r=Math.max(1,Math.min(11,round));
        return Math.max(50,Math.min(99,get(c).getInt("round_threshold_"+r,threshold(c))));
    }
    public static void setRoundThreshold(Context c,int round,int value){
        int r=Math.max(1,Math.min(11,round));int v=Math.max(50,Math.min(99,value));get(c).edit().putInt("round_threshold_"+r,v).apply();
    }
    public static void setAllRoundThresholds(Context c,int value){
        SharedPreferences.Editor e=get(c).edit();int v=Math.max(50,Math.min(99,value));e.putInt(THRESHOLD,v);for(int r=1;r<=11;r++)e.putInt("round_threshold_"+r,v);e.apply();
    }

    private static String p(String kind,String suffix){return "region_"+kind+"_"+suffix;}
    public static boolean hasRegion(Context c,String kind){
        if(REGION_VISIBLE.equals(kind) && get(c).contains(REGION_SET)) return get(c).getBoolean(REGION_SET,false);
        return get(c).getBoolean(p(kind,"set"),false);
    }
    public static RectF region(Context c) { return region(c,REGION_VISIBLE); }
    public static RectF region(Context c,String kind) {
        SharedPreferences sp=get(c);
        if(REGION_VISIBLE.equals(kind) && sp.contains(REGION_SET)){
            return new RectF(sp.getFloat(REGION_L,.59f),sp.getFloat(REGION_T,.48f),sp.getFloat(REGION_R,.77f),sp.getFloat(REGION_B,.60f));
        }
        float dl=.59f,dt=.48f,dr=.77f,db=.60f;
        if(REGION_HIDDEN.equals(kind)){dl=.08f;dt=.42f;dr=.43f;db=.72f;}
        if(REGION_OPPONENT.equals(kind)){dl=.05f;dt=.20f;dr=.95f;db=.88f;}
        return new RectF(sp.getFloat(p(kind,"l"),dl),sp.getFloat(p(kind,"t"),dt),sp.getFloat(p(kind,"r"),dr),sp.getFloat(p(kind,"b"),db));
    }
    public static void saveRegion(Context c, RectF n) { saveRegion(c,REGION_VISIBLE,n); }
    public static void saveRegion(Context c,String kind,RectF n) {
        SharedPreferences.Editor e=get(c).edit().putBoolean(p(kind,"set"),true).putFloat(p(kind,"l"),n.left).putFloat(p(kind,"t"),n.top).putFloat(p(kind,"r"),n.right).putFloat(p(kind,"b"),n.bottom);
        if(REGION_VISIBLE.equals(kind))e.putBoolean(REGION_SET,true).putFloat(REGION_L,n.left).putFloat(REGION_T,n.top).putFloat(REGION_R,n.right).putFloat(REGION_B,n.bottom);
        e.apply();
    }
}
